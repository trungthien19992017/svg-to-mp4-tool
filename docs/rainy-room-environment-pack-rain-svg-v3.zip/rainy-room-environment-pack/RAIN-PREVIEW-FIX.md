# Rain visibility fix

Open `previews/environment-preview.html` in Chrome/Edge. Rain starts automatically. Use Rain on/off and Pause/Play, or scrub the timeline. The window fill was made transparent enough to reveal the rain-back layer. This preview is not the production motion library.
