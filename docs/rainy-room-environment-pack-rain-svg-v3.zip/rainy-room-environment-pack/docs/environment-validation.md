# PHASE 02C — Environment Validation

**Verdict: CONDITIONAL PASS (layout concept only).** One room can support all five scenes, but character placement, contact, seated framing and layered SVG feasibility are **not production-approved**. No runtime tests were performed.

## Evidence
- Master raster: **941 × 1672** (approximately 9:16), not native 1080 × 1920. Resize for layout; vector rebuilding is a separate phase.
- Art Bible/layout from Phase 02A and Character Pack V4 available. V4 SVG viewBox is 500 × 780 for each robot, **not physical size in scene**. Rig validation report says static poses Partial, and Studio integration not run.
- Storyboard: 30 seconds, **24 FPS**, five scenes; title **Tưởng lãng mạn hóa ra đòi nợ**. This supersedes the original simple touch-only premise for shot planning.

## Review of 10 requirements
| Item | Assessment | Finding / action |
|---|---|---|
| 1. Ratio | PASS with resize | Source ~9:16; upscale to 1080×1920. |
| 2. Floor contact | CONDITIONAL | Wall/floor junction ~y1100; feet line proposed y1415. Floor has strong readable plank perspective. |
| 3. Relative scale | PROVISIONAL | Rendered robot height ~570 px is a composition proposal, not validated real-world scale. |
| 4. Raised arms | CONDITIONAL | Central area clear; use exact wrist trajectories to validate. |
| 5. Hand contact | PROVISIONAL | Proposed shared point x535,y1110; must recalculate from actual posed hands. |
| 6. Occlusion | CONDITIONAL | Foreground plants at bottom left and books/lantern at bottom right; avoid crossing feet or seated silhouettes. |
| 7. Focal hierarchy | PASS with caution | Bright window left and amber lamp right balance composition; star lanterns and lamp may compete with face close-ups. Lower their animation intensity during twist. |
| 8. Separable layers | PARTIAL | Conceptual layer groups identifiable, but approved image is a **single flattened raster**; clean separation needs repaint/reconstruction and cannot be guaranteed automatically. |
| 9. Wide/close | CONDITIONAL | Wide has rich context; close crops can be made from same master but raster zoom may soften details. |
| 10. Character contrast | CONDITIONAL | Cream male may blend into warm wall; pastel blue female may blend with window. Use restrained cool rim/soft contact shadow and local contrast, not a room redesign. |

## Blocking and staging
- Suggested initial arrangement: **male left (355,1415), female right (715,1415)**, bottom-center foot anchors. Proposed 570 px rendered height for each, provisional.
- Interaction clear zone: x275–820, y820–1500. Shared hand contact target: (535,1110), provisional.
- For the invoice reveal, keep the paper in front of the torsos and within the medium/close crop.
- For seated outro, move feet/seat anchors and camera down; **do not reuse standing ground anchors**.
- The earlier layout's ground boundary y1420 was only a proposal; the approved picture visually places the wall/floor junction nearer y1100.

## Camera continuity
- A Wide: full 1080×1920 source.
- B Medium: source crop [170,560,740,1316], scaled to output.
- C Close: source crop [280,820,520,924], scaled to output. This is an action crop; a separate face-centered close crop is required for the surprise reaction.
- Shot rectangles are **provisional** until actual robot transforms and approved pose silhouettes are locked.

## Storyboard / asset blockers
- Scene 2 hand-holding front is Unsupported in the supplied storyboard; scene 3 gentle hug front Unsupported; scene 4 invoice-grab artwork/anchor incomplete; scene 5 sitting and shoulder-lean are Partial.
- Scene 5 sitting order is ambiguous in the storyboard.
- Storyboard notes conflicting male/female gift roles in the interaction catalog; female must reveal the invoice per story.
- Storyboard warns a prior package configuration was 1080×800; output contract must be **1080×1920, 24 FPS** for this story.

## Recommendation
Proceed to SVG environment reconstruction **only after** accepting the conditional layout and defining actual character scene scale, standing/seated anchors, and contact poses. Keep approved room geometry and color design unchanged.
