# Phase 02E Integration Notes

- Native vector reconstruction of approved rainy room PNG. The artwork is an approximation, **not pixel-identical**; visual approval required.
- Coordinate system: 1080 × 1920, SVG `viewBox=0 0 1080 1920`.
- Layer order: `metadata/layer-order.json`. Characters are preview-only insertion between furniture and foreground.
- Rain asset IDs in SVG are original per-file IDs; HTML preview prefixes IDs when composing DOM. Implement an equivalent ID namespace step in the actual host.
- Rain back, rain glass and reflections from supplied Phase 02D V2. Rain config preserved unchanged.
- Window pane clipping is inherited from Phase 02D and **provisional**. Inspect against rebuilt window before production.
- Preview uses local JavaScript and deterministic `t`, no external CDN. This is not the Phase 03 motion library.
- Camera presets and placements remain provisional.
- Studio API contract not supplied. Studio runtime compatibility **NOT TESTED**.
- Story ZIP integration (Phase 06) not tested.
