# Rain SVG V3

- Open `previews/rainy-room-animated.svg` directly in Chrome/Edge: SVG rain auto-plays.
- Open `previews/environment-preview.html` for controls (rain toggle, pause, reset, camera).
- Native SMIL `<animateTransform>` embedded in `rain-back.svg` and `rain-glass.svg`.
- `walls.svg` modified to cut a transparent window opening so exterior rain is not hidden.
- Rain is clipped to four window panes, and cannot overlap character contact area.
- Previous source versions retained with `-pre-smil.svg` suffix.
- SVG SMIL is for visual preview, NOT deterministic Studio production motion; replace/control via GSAP in Phase 03.
- Window mask geometry and camera presets remain provisional.
- Visual browser QA: NOT TESTED. SVG/XML/ZIP checks are run.
