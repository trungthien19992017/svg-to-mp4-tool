# Gói ảnh tham chiếu – Kịch bản 1 "Tưởng lãng mạn hóa ra đòi nợ"

Video: 1080×1920 (9:16), 30 giây, 24fps. Nền: "Góc phòng ấm áp ngày mưa" (file riêng). Ảnh tham chiếu dùng tạm, chờ artwork mới. Nguồn: character-pack-v4.

## Ảnh theo phân cảnh
| Cảnh | Thời lượng | Tư thế cần dựng | Ảnh tham chiếu |
|---|---|---|---|
| 1 Hook | 0:00–0:03 | Cả hai đứng nhìn nhau (Nam Loving) | 1-hook/touch-hand-1.png |
| 2 Phát triển | 0:04–0:10 | Nữ chìa tay (Open Greeting) → Chạm tay → Nắm tay | 2-cham-tay-nam-tay/touch-hand-2, touch-hand-3, hold-hand-1..4 |
| 3 Cao trào | 0:11–0:18 | Nam tiến lại định ôm nhẹ (Shy → Touched) | 3-om-nhe/gentle-hug-2, gentle-hug-3, gentle-hug-4 |
| 4 Twist | 0:19–0:25 | Nữ rút tờ hóa đơn, Nam Surprised | 4-twist-hoa-don/invoice-prop.svg (không có tham chiếu tư thế) |
| 5 Outro | 0:26–0:30 | Cả hai ngồi (Sitting), Nam Pleased → Nữ Cheerful, tựa vai | 5-ngoi-tua-vai/lean-on-shoulder-1, 3, 4 |

## Tư thế chưa có ảnh tham chiếu
- Cảnh 2: Nữ chìa tay (gesture-open-greeting) chỉ có ảnh cánh tay tách riêng trong pack gốc, không nằm trong zip này.
- Cảnh 4: Nữ rút/cầm hóa đơn (không có tham chiếu).
- Cảnh 5: Nam và Nữ ngồi bệt riêng (references/poses/*-sitting.png không nằm trong zip).

## File hỏng trong character-pack-v4.zip (đã loại khỏi gói này)
- touch-hand-4.png: 0 byte (khung thoát của Chạm tay)
- gentle-hug-1.png: bị cắt dở (khung vào của Ôm nhẹ)
- lean-on-shoulder-2.png: bị cắt dở

## Biểu cảm (chỉ góc front)
Nam: Loving, Shy, Touched, Surprised, Pleased. Nữ: Cheerful. Biểu cảm của Nữ ở cảnh 1, 2, 3, 4 chưa chốt.

## Tờ hóa đơn
invoice-prop.svg: 360×470, nét viền #152d3d, màu hồng #ff9fbe và xanh #a4dee8 theo bảng màu hai robot. Nội dung: HÓA ĐƠN / Trà sữa hôm qua / 55 cành. Chữ dùng font hệ thống (chưa chuyển thành path). Hai điểm neo cầm grip-left và grip-right đặt tạm ở mép trái/phải, cần chỉnh khi có tư thế cầm.
