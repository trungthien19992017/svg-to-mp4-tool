# Phase 02D Rain Pack V2

Open `rain-preview.html` locally in Chrome/Edge. Toggle each layer, play/pause, and scrub.

Background is a regenerated clean-rain variant, not pixel-identical to the approved original. Pane clip masks remain provisional. Preview is not a Studio runtime integration.
