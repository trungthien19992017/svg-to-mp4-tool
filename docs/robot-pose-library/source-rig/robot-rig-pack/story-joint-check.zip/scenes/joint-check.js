import {applyPose} from '../modules/rig-runtime.js';
export function createScene(context){
const rigs=JSON.parse(context.assetText('rig-data')).rigs;
const actors=rigs.map((r,i)=>context.addSvg(context.assetText(r.id),{x:30+(i%3)*470,y:15+Math.floor(i/3)*440,scale:0.50}));
function seek(t){const a=Math.sin(t*Math.PI/2),b=Math.sin(t*Math.PI);const pose={head:12*a,'upper-arm-L':50*a,'forearm-L':40*b,'upper-arm-R':-50*a,'forearm-R':-40*b,'thigh-L':25*a,'shin-L':35*b,'foot-L':-12*b,'thigh-R':-25*a,'shin-R':-35*b,'foot-R':12*b};actors.forEach((actor,i)=>applyPose(actor,rigs[i],pose));}
seek(0);return {duration:8,seek,reset(){seek(0)},dispose(){actors.forEach(a=>a.remove())}};
}
