# Character Pack — calibrated v2

Mở pair-scale-review.html để xem ảnh chuẩn / rig mới / rig cũ và overlay. Mở rig-inspector.html để chỉnh từng khớp, đổi giữa 6 góc và kiểm tra pivot/anchor. Mở pair-preview.html hoặc anchor-debug-view.html để kiểm tra tương tác. Tải HTML về và mở bằng Chrome/Edge; không cần server.

assets/ chứa 6 body rig mới. character-rig.json và pivots-and-anchors.csv là tọa độ chuẩn v2. pair-calibration.json chứa tỷ lệ chiều cao và scale cố định của mỗi nhân vật.

pose-catalog.json, motion-library.json, expression-catalog.json và interaction-catalog.json đã được cập nhật. Partial vẫn là Partial: ảnh tham chiếu có thật không đồng nghĩa đã có pose/gesture vector được bind. references/ và interactions/references/ lưu crop nguồn có provenance; inputs/ giữ dữ liệu cũ để đối chiếu, không dùng làm runtime mặc định.

facial/ giữ nguyên SVG facial và runtime trước đó. facial-adapter.js hỗ trợ mount vào head front đúng tọa độ nguồn; mỗi view không có biểu cảm hợp lệ vẫn Unsupported. Head source pivot không đổi dù torso và limb mounts thay đổi.

Nghiệm chạm tay v2 đạt kiểm tra điểm và bề mặt. Không đổi scale chi, mount hoặc bone length khi chạy. Không suy diễn touch thành nắm tay, ôm hoặc gift handoff. Nhìn nhau chưa có góc đối diện được duyệt.

Đọc validation-report.md để biết phạm vi kiểm tra và những phần còn thiếu. Đây là Character Pack/review package, không phải Story ZIP để import trực tiếp.

Body SVG displayViewBox includes padding so raised limbs are not cropped. Native bone/anchor coordinates remain unchanged; use anchors for placement, not the padded image width.
