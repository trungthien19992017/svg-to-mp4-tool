# Calibrated couple interaction library v2

Open pair-preview.html or anchor-debug-view.html in Chrome/Edge. Native rigs and contact anchors are v2 with calibrated per-actor scale. Geometric touch at phase 0.5 has passed numerical and pixel-surface checks; holding grip, head-facing/gaze, comfort, independent seated/hug and prop binding remain incomplete as stated in interaction-catalog.json.

assets/, character-rig.json, pair-calibration.json and surface-contact-validation.json are current. Reference keys are preserved raster crops; they are not independent SVG layers. inputs/ retains original user catalogs as provenance only.

The consolidated Character Pack v2 additionally contains pair-scale-review.html, rig-inspector.html, facial modules and updated pose/motion catalogs. Use that consolidated pack as the production source; this ZIP is the standalone interaction review subset.
