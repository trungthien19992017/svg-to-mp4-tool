# Character Pack v2 — Hiệu chỉnh tỷ lệ cơ thể

## Kết quả

Đã dựng lại thân, tay và chân của cả 6 rig (nam/nữ × front/3/4/side), cập nhật pivot, bone length và anchor theo hình mới. Hình đầu/visor từng góc và 6 facial SVG được giữ nguyên.

Chuẩn chính: ô trên trái của **couple-action-sheet-hold-hand(1).png**. Model sheet tiếp tục quyết định hình đầu/visor theo từng góc. Không dùng đầu front để giả lập góc bên.

| Mục | V1 | V2 |
|---|---|---|
| Chiều cao native nam (đỉnh đầu đến sole) | khoảng 766,5 px | 698.0 px |
| Chiều cao native nữ (gồm nút hồng) | khoảng 631,5 px | 692.0 px |
| Scale toàn thân nam | 0,7 | 0.70000000 |
| Scale toàn thân nữ | 0,7 | 0.73362329 |
| Tỷ lệ chiều cao hiển thị nữ/nam | khoảng 0,824 | 1.03902439 |
| Chuẩn đo từ ảnh đôi | Chưa áp dụng | 426 / 410 = 1.03902439 |

Chiều dài chi được thay đổi ở **thiết kế rest pose**. Khi chạy, scale chi luôn bằng 1; mount và chiều dài xương không thay đổi. Mỗi nhân vật dùng một scale toàn thân cố định đã hiệu chỉnh, không đổi scale trong quá trình giải tiếp xúc.

## Cách đo và giới hạn đối chiếu

Reference bounds đo từ viền tối của từng nhân vật trong ô trung tính, loại khung và bóng đổ. Bounds nam: [89, 95, 326, 505]; nữ: [393, 72, 630, 498]. Tổng chiều cao tính cả nút hồng; khi xem tỷ lệ đầu/helmet thì nút hồng được tách riêng. Sai số ảnh nguồn khoảng 1–2 pixel.

Tỷ lệ tổng chiều cao v2 được FIT theo số đo ảnh chuẩn; việc sai số fit bằng 0 là kết quả của phép hiệu chỉnh, không phải chứng minh mọi landmark trùng pixel. Góc nhìn và hình đầu production được giữ nguyên, nên overlay toàn hình không trùng hoàn toàn với đầu hơi nghiêng trong ảnh đôi. Các phần thân/chi, mốc vai/hông và baseline được đối chiếu riêng. Minor đường ráp có thể còn thấy khi gập chi mạnh; không tuyên bố mọi tư thế đã đạt chất lượng diễn xuất cuối.

## Pivot, anchor và thứ tự lớp

- Tọa độ local pivot tại (0,0); parent mount cập nhật theo geometry v2.
- Vai/khuỷu/cổ tay/hông/gối/cổ chân và sole/toe được xuất trong character-rig.json và pivots-and-anchors.csv.
- Hand contact nam ở bán kính ngoài 35 px; nữ ở bề mặt cap tay/forearm gồm viền, 32,5 px. Các điểm contact v1 nằm sâu hơn trong mảng tay nên đã được thay.
- Head side-L/side-R và top được đo từ silhouette render của đầu giữ nguyên, độ chính xác khoảng 1 px; face vẫn là điểm định hướng giữa mặt, không phải bề mặt tiếp xúc.
- Z-order giữ chân/chi xa sau thân, tay gần và đầu phía trước. Không xóa mặt hoặc thân để che va chạm.

## Kiểm tra khớp

336 pose được thử: neutral, 33 thời điểm trong bài sweep và từng khớp tại hai giới hạn. Kết quả cả 6 rig: không có cặp khớp kề nhau mất vùng chồng. Kiểm tra mask ở tỷ lệ 1/2, dùng để phát hiện rời khớp, không thay cho duyệt hình diễn xuất. Render sau seek ngược trùng hash tại thời điểm lặp.

## Chạm tay sau hiệu chỉnh

Đã tìm nghiệm trong giới hạn góc khớp và giữ sole trên sàn. Không sửa mount hoặc chiều dài xương trong khi giải.

- Sai số hai contact anchor: 1.137e-13 px.
- Khoảng cách bề mặt trên ảnh render: 1.0 px (tiếp tuyến ở độ phân giải raster).
- Pixel hai nhân vật chồng nhau: 0; chồng ngoài vùng tiếp xúc: 0.
- Sai số sole so với sàn: 0.000 px.
- Khoảng an toàn proxy đầu: 32.509 px.
- Tất cả góc trong giới hạn được định nghĩa.

Nghiệm này chứng minh **geometric touch**, không tự biến hai mảng tay thành holding grip. Nắm tay, tựa đầu, ngồi độc lập, an ủi và ôm vẫn cần artwork/binding tương ứng.

## Kiểm tra trình duyệt

Chromium 153, mở bằng file://:

- 15 trường hợp trong trang đối chiếu tỷ lệ (3 góc × 5 pha): PASS.
- 42 mẫu trong joint inspector cho cả 6 rig: PASS; sai số anchor so với DOM tối đa 0.000002816 px.
- 24 biểu cảm từ facial SVG cũ được mount và blink trên head v2 qua adapter: PASS; artwork facial không thay đổi.
- 126 trường hợp tương tác/chế độ/pha: PASS; sai số anchor DOM tối đa 0.000028988 px; sai số sole tối đa 0.000023633 px.
- Seek ngược của cả 9 tương tác: giống trạng thái SVG tại thời điểm lặp.
- JavaScript errors: không có.

## Ảnh hưởng catalog và tài nguyên

- Pose catalog v3: {"Supported": 8, "Partial": 26}. Các trạng thái đứng sử dụng SVG v2 thật. Pose khác giữ ảnh nguồn tham chiếu, chưa được tuyên bố là pose vector v2.
- Motion catalog v3: {"Partial": 10}. Các key nguồn được đóng gói lại với provenance và đường dẫn thực; vẫn Partial vì timing/binding/foot-lock chưa được duyệt trên skeleton mới. Không tái dùng tọa độ world v1.
- Interaction catalog: tỷ lệ và placement v2 đã áp dụng; geometric touch đạt kiểm tra. 7 Partial / 2 Unsupported vẫn được giữ, vì không tự tạo grip, gift prop, comfort pose hoặc góc nhìn đối diện.
- Facial rig: 12 ID mỗi nhân vật, SVG giữ nguyên; adapter dùng đúng pivot nguồn front, không kéo méo biểu cảm theo thân mới. Các giới hạn view/quality trước đó vẫn được ghi lại.
- Input JSON và rig v1 giữ trong inputs/ để đối chiếu. Các đường dẫn source cũ còn tồn tại dưới dạng provenance, không phải dependency production hiện tại.

## Những phần chưa hoàn thiện

“Nhìn nhau” chưa có artwork nhìn đối diện/gaze axis đã duyệt, nên hiển thị rõ Unsupported và chỉ dùng rig trung tính làm ngữ cảnh kiểm tra tỷ lệ. Các ảnh ôm/ngồi/tựa vai vẫn là tham chiếu composite, chưa thành các lớp SVG độc lập có contact binding. Các clip nguồn chưa có timing được duyệt. Không có cảnh Story sản xuất hoặc MP4 nào được cung cấp để migrate; không tuyên bố đã sửa các tập phim cũ.

Hãy dùng **Character Pack calibrated v2** làm nguồn chính. Không trộn rig v2 với pivot/world placement từ JSON v1 hoặc lấy toàn thân trong ZIP trace cũ làm geometry hiện hành.
