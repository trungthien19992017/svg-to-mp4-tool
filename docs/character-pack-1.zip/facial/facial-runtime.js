const features=['eyes','eyebrows','mouth','cheeks','tears','highlights'];
export function setExpression(root,id){
 if(root.getAttribute('data-view')!=='front'||root.getAttribute('data-expression-rig')!=='true')throw new Error('Unsupported expression view');
 const state=[...root.querySelectorAll('[data-expression]')].find(n=>n.getAttribute('data-expression')===id);
 if(!state)throw new Error('Unknown expression '+id);
 root.querySelectorAll('[data-expression]').forEach(n=>n.setAttribute('visibility',n===state?'visible':'hidden'));
 root.setAttribute('data-active-expression',id);setBlink(root,0);return state;
}
export function setBlink(root,closure){
 if(!Number.isFinite(closure))throw new Error('Blink closure must be finite');const c=Math.max(0,Math.min(1,closure));
 const state=[...root.querySelectorAll('[data-expression]')].find(n=>n.getAttribute('visibility')==='visible');if(!state)throw new Error('No active expression');
 const closed=state.getAttribute('data-closed-eyes')==='true';
 for(const layer of ['eyes','highlights']){
  const group=state.querySelector('[data-feature="'+layer+'"]');
  group.querySelectorAll('[data-blink-pivot]').forEach(n=>{const [x,y]=n.getAttribute('data-blink-pivot').split(' ').map(Number);const sy=closed?1:1-.96*c;n.setAttribute('transform','translate('+x+' '+y+') scale(1 '+sy+') translate('+(-x)+' '+(-y)+')');n.setAttribute('opacity',layer==='highlights'&&!closed?1-c:1)})
 }root.setAttribute('data-blink',c);
}
export function setFeature(root,feature,opacity){if(!features.includes(feature))throw new Error('Unknown feature');if(!Number.isFinite(opacity))throw new Error('Opacity must be finite');root.querySelectorAll('[data-expression] > [data-feature="'+feature+'"]').forEach(n=>n.setAttribute('opacity',Math.max(0,Math.min(1,opacity))))}
