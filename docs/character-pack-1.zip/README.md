# Character Pack — final review delivery

Open pair-preview.html. Open anchor-debug-view.html for anchor overlays.
approved-pair-review.html contains the accepted four-pose review.
assets/robot-women-three-quarter-left.svg is the mirrored left-facing view.

The interaction catalog defines nine interactions and their availability.
asset-requests.json lists remaining artwork and rig binding requirements.
Read validation-report.md for current verification limits.
