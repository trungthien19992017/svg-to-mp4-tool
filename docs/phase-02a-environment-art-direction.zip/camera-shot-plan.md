# Camera Shot Plan — One Environment / Five Scenes

**Canvas:** 1080 × 1920 · 30 fps · 30 seconds · **All crops and camera transforms provisional.**

## Shared camera grammar

Một background master duy nhất. Mọi shot đều lấy từ cùng scene graph; thay đổi camera root translation/scale, không redraw hoặc đổi phối cảnh. Điểm nhìn 2D chính diện, parallax rất nhẹ. Vùng chạm tay luôn nằm trong safe frame, trừ close-up chủ ý.

| Shot size | Purpose | Approximate scale | Framing guide | Provisional |
|---|---|---:|---|---|
| Wide | Thiết lập phòng và vị trí hai robot | 1.00× | Thấy cửa sổ, đèn, sàn và cả hai robot | Yes |
| Medium | Ánh mắt, khoảng cách và tay đưa ra | 1.20–1.40× | Hai thân trên và bàn tay; nền vẫn nhận diện được | Yes |
| Close-up | Chạm tay và phản ứng tinh tế | 1.65–2.10× | Tay/biểu cảm; chỉ crop từ cùng master | Yes |

**Scale là gợi ý camera, không phải scale nhân vật.** Khi cần close-up cả mặt và tay mà không đủ chỗ, dùng một cut riêng cùng background, không bóp méo bố cục.

## Five-scene plan

| Scene | Time | Shot | Camera and action | Background motion |
|---|---|---|---|---|
| 01 | 00:00–00:06 | Wide | Giới thiệu hai robot cạnh cửa sổ; khóa bố cục | Mưa đều, đèn sáng dịu |
| 02 | 00:06–00:12 | Medium | Robot nữ ngập ngừng, ánh mắt nhìn về tay nam | Push-in rất nhẹ |
| 03 | 00:12–00:18 | Medium | Robot nam nhận ra, chủ động đưa tay | Camera giữ ổn định, ưu tiên silhouette tay |
| 04 | 00:18–00:24 | Close-up | Hai bàn tay tiến đến rồi chạm | Giữ contact anchor ở vùng trọng tâm |
| 05 | 00:24–00:30 | Medium → Wide | Hai robot mỉm cười, camera lùi nhẹ | Glow ấm tăng tinh tế, mưa tiếp tục |

Thời lượng 6 giây/cảnh là **đề xuất provisional**, chưa được xác nhận với storyboard/timeline cuối cùng.

## Boundary continuity

- **01→02:** cùng vị trí chân và tư thế cuối shot 01; chỉ crop/push-in.
- **02→03:** hướng mắt và vị trí tay nữ không nhảy; robot nam bắt đầu từ pose đã chốt.
- **03→04:** vị trí hai bàn tay phải khớp pixel-space khi chuyển sang crop mới.
- **04→05:** duy trì contact pose rồi mới mở khung; không reset biểu cảm khi cắt cảnh.

## Camera implementation notes

- `environment-camera`: master transform; `rain-far`, `lamp-glow` animate độc lập.
- Mưa nằm trong `clipPath` cửa sổ; không tràn vào phòng.
- Không animate camera và character rig theo hai hệ tọa độ chưa được map; convert contact anchor sang cùng world-space.
- Giữ vùng an toàn cho tiêu đề/phụ đề nếu được bổ sung sau.

## Pending confirmations

1. Approved Character Pack: bounding boxes, foot pivots, hand contact anchors, final approved poses.
2. Approved storyboard: chính xác thời lượng từng cảnh, pose đầu/cuối, trọng tâm close-up.
3. Camera safe area: vị trí chữ/subtitle hoặc UI TikTok nếu có.
