# Environment Art Bible — Chạm một chút thôi

**Phase:** 02A · **Format:** 1080 × 1920 portrait · **Duration:** 30s · **Status:** Proposed, not approved

## 1. Creative intent

**Rainy Window, Warm Hearts.** Một căn phòng nhỏ ấm áp trong chiều mưa, yên tĩnh và giàu khoảng thở. Không gian dẫn mắt từ cửa sổ mưa lạnh (trái), qua khoảng trống tương tác ở giữa, đến đèn ấm (phải). Tập trung vào cảm xúc ngại ngùng, chủ động và chạm tay, không vào đồ trang trí.

**Visual language:** Cozy 2D Storybook Animation, soft vector illustration, hình khối bo tròn, nét sạch, bóng mềm, không texture photorealistic, không phối cảnh 3D phức tạp. Ưu tiên path đơn giản, gradient ít stop và mask rõ ràng để sản xuất SVG.

## 2. Single-room spatial composition

- **Hậu cảnh:** tường kem, cửa sổ lớn bo góc lệch trái phía trên; bầu trời xanh mưa, vài silhouette xa, giọt mưa sau kính. Khung cửa không xuyên qua silhouette nhân vật.
- **Trung cảnh:** sàn gỗ bắt đầu từ một đường chân tường ngang rõ ràng; các ván sàn giản lược tạo cảm giác tiếp đất. Đèn đứng thân mảnh bên phải, bóng sáng ấm hắt vào vùng trung tâm.
- **Đồ trang trí:** 1 chậu cây nhỏ hoặc 2–3 quyển sách ở rìa phải; không dùng bàn/ghế lớn. Thảm chỉ xuất hiện nhẹ ở cạnh dưới, không che chân.
- **Tiền cảnh:** một vài mảng hình mềm sát mép dưới hoặc mép bên; dịch chuyển parallax rất nhỏ, không che bàn tay.
- **Khoảng thở:** vùng giữa được giữ sạch cho hai robot và chuyển động tay; hạn chế pattern trên tường.

### Layout coordinates

Hệ tọa độ 1080 × 1920, gốc trên trái. Bố cục tham khảo: cửa sổ x=9–57% / y=16–58%; đèn x=79–94% / y=40–74%; ranh giới tường–sàn y≈74%; vùng tương tác x=24–80% / y=43–91%. **Toàn bộ là provisional**, không phải kích thước hoặc vị trí khóa cứng.

Robot nam **bên trái**, robot nữ **bên phải** (đề xuất, provisional). Tọa độ chân tham khảo lần lượt (40%,83%) và (66%,83%). Điểm chạm tay tham khảo (53%,66%) **phải tính lại từ contact anchors của rig**. Không suy diễn tỷ lệ từ `viewBox` SVG 500 × 780.

## 3. Visual hierarchy and silhouette

1. Mặt/màn hình robot và hướng mắt.
2. Hai bàn tay cùng điểm tiếp xúc.
3. Tương phản ánh sáng ấm–lạnh.
4. Cửa sổ và chuyển động mưa nền.
5. Trang trí phụ.

Tránh các thanh khung cửa, thân đèn, đường sàn đi xuyên qua bàn tay trong medium/close-up. Robot nam kem cần viền mát nhẹ để tách khỏi tường kem; robot nữ xanh pastel cần viền ấm nhẹ để tách khỏi nền cửa sổ xanh.

## 4. SVG layer plan (back → front)

| Order | SVG group ID | Content | Motion |
|---|---|---|---|
| 01 | `sky-color` | Bầu trời ngoài cửa | Static |
| 02 | `distant-silhouettes` | Nhà/cây xa | Parallax 0.15× |
| 03 | `rain-far` | Vệt mưa xa, masked | Loop |
| 04 | `window-glass` | Kính mờ nhẹ | Static |
| 05 | `window-frame` | Khung cửa | Static |
| 06 | `wall-base` | Tường | Static |
| 07 | `wall-details` | Phào chỉ nhẹ | Static |
| 08 | `floor-base` | Nền sàn | Static |
| 09 | `floor-planks` | Đường ván sàn | Static |
| 10 | `lamp-body` | Đèn đứng | Static |
| 11 | `lamp-glow` | Quầng sáng gradient | Opacity pulse |
| 12 | `decor` | Cây/sách nhỏ | Static |
| 13 | `character-shadows` | Bóng tiếp đất | Follow feet |
| 14 | `characters` | Robot từ Character Pack | Rig animation |
| 15 | `rain-glass-highlights` | Giọt nước phản sáng, chỉ trong vùng kính | Slow loop |
| 16 | `foreground-edge` | Trang trí sát mép | Parallax 1.15× |
| 17 | `color-grade-overlay` | Grade rất nhẹ | Optional |

**Technical:** mỗi group có ID ổn định; dùng `clipPath` riêng cho mưa và kính; tách đèn sáng khỏi thân đèn; không rasterize robot hoặc background; camera transform một root `environment-camera`, các lớp parallax dùng offset phụ. Thông số chuyển động đều provisional, cần đối chiếu animation contract trước khi triển khai.

## 5. Color and lighting

| Role | Color | Use |
|---|---|---|
| Warm cream | `#F5E9D8` | Tường |
| Wood | `#C69C7B` | Sàn và viền |
| Rainy blue | `#809BA9` | Trời mưa |
| Shadow blue | `#516879` | Bóng lạnh |
| Lamp glow | `#F4C98C` | Ánh đèn |
| Soft pink | `#DCA9B5` | Điểm nhấn nhỏ |

Ánh cửa sổ lạnh, khuếch tán, từ trái vào. Ánh đèn vàng ấm từ phải vào, quầng mềm và không cháy sáng. Bóng chân mềm, độ tương phản vừa phải. Không dùng bóng đen cứng, bloom nặng hoặc gradient phức tạp. Các mã bổ sung có trong `color-palette.json`.

## 6. Continuity and production guardrails

- Chỉ **một** căn phòng và một bố cục; 5 cảnh thay bằng crop/zoom/pan, không thay góc nhìn nền.
- Giữ cửa sổ, đèn, đường tiếp đất và ánh sáng ở vị trí tương đối cố định.
- Giữ bàn tay, chân và hướng nhìn nhất quán qua scene boundaries; không tự động mirror nền.
- Cỡ robot, scale, điểm tiếp đất, góc quay và contact anchors: **provisional** cho đến khi duyệt Character Pack và shot blocking.
- Background phải xuất được thành các nhóm SVG vector riêng, không flatten.

## 7. Reference strategy

Không sử dụng ảnh ngoài ở phase này. Khi cần moodboard, tìm các chủ đề: *cozy storybook rainy window room illustration*, *pastel vector warm lamp interior*, *2D animation background rainy day*. Chỉ tham khảo mood, phân lớp và ánh sáng; không sao chép bố cục hay tác phẩm cụ thể.

## 8. Handoff / approval gates

**Có thể duyệt ngay:** mood, palette, vị trí tương đối cửa sổ/đèn, danh sách layer, camera philosophy.

**Chưa khóa:** scale nhân vật, tọa độ chân/tay, framing từng shot, z-order tại điểm tiếp xúc, độ dịch parallax thực tế. Những thông số này chờ approved Character Pack và pose blocking.
