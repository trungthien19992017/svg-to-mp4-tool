# PHASE 03 — Reusable GSAP Motion Library

## Input contracts and source fidelity

- Story Production & Animation Code Contract v1: `createScene(context)` returns `duration`, synchronous `seek`, `reset`, `dispose`. Studio supplies `context.gsap` and a **paused** `context.timeline()`; no new Studio APIs are used.
- Character Pack V4: source `robot-male.svg` / `robot-female.svg` are copied **byte-for-byte**. All 12 front-view facial states per actor are preserved; non-front facial swaps are not supported by V4.
- Environment Rain SVG V3: vector geometry is preserved. SMIL rain translations were converted to `data-rain-*` values, evaluated at absolute timeline time to prevent autonomous animation. No other background geometry was redrawn.
- The 8-second example is **technical choreography**, not approval of final motion artwork. No IK or physics engine is created.

## Source modules

| File | Purpose |
|---|---|
| `modules/motion-library.js` | Reusable action scheduling, channel overlap guard, easing, pure-time state evaluation, paused GSAP clock adapter |
| `modules/actor.js` | Apply motion state to actual V4 SVG rig nodes, preserve joint mounts and rest lengths, render front expression and blink |
| `modules/rig-data.js` | Compact source-derived front rig metadata and V4 contact solution |
| `modules/rain.js` | Seek-controlled V3 rain, independent of browser/SMIL clocks |
| `modules/svg-namespace.js` | Prefix SVG IDs and rewrite local references for multiple actors/scenes |
| `scenes/scene-001.js` | 8-second Studio scene using the modules |

## API

```js
import {createMotionComposer, createTimelineMotion} from '../modules/motion-library.js';

const composer = createMotionComposer({
    duration: 8,
    gsap: context.gsap,
    actors: {
        male: {x: 225, y: 238.45, scale: 0.7},
        female: {x: 539.2187426, y: 218.760652, scale: 0.73362329}
    }
});
composer.add('headTilt', 'male', 3.75, 0.55, {
    id: 'male-tilt', from: 0, to: 4, easing: 'sine.inOut'
});
composer.finalize();

const controller = createTimelineMotion(context, composer, (states, time) => {
    maleActor.render(states.male);
    femaleActor.render(states.female);
});
return {
    duration: 8,
    seek(time) { controller.seek(time); },
    reset() { controller.reset(); },
    dispose() { controller.dispose(); }
};
```

`composer.add(type, actorId, startSeconds, durationSeconds, options)` returns an immutable action record containing `start`, `end`, `duration`, `easing`, and exclusive channels. `composer.evaluate(t)` produces a **fresh, complete state** from time alone. The director rejects overlapping writes to the same channel of the same actor, including walk-vs-reach arm conflicts. Adjacent actions may meet at an exact boundary. All `from`/`to` values are explicit; no property is inferred from the last seek.

## Action inventory and statuses

| Action | Channel(s) | Start → End | Status |
|---|---|---|---|
| `idle` | head-y | rest → rest (finite bob) | Partial |
| `blink` | blink | eyes open → open | Partial |
| `breathe` | neck-y | neutral → neutral (finite oscillation) | Partial |
| `lookAt` | head-rotation | in-plane from → to | Partial |
| `headTilt` | head-rotation | in-plane from → to, ±15° limit | Partial |
| `happyReaction` | expression, head-y | previous face → authored `pleased` | Partial |
| `surprisedReaction` | expression, head-y | previous face → authored `surprised` | Partial |
| `sadReaction` | expression, head-rotation | previous face → authored `sad` | Partial |
| `reach` | arm-near | authored target × fromFactor → × toFactor | Partial |
| `touch` | arm-near | authored target × 0.92 → × 1 | Partial |
| `release` | arm-near | authored target × 1 → × 0 | Partial |
| `walk` | actor-x, gait, arm-near | xFrom/gait 0 → xTo/gait 1 | Partial |
| `stopWalking` | gait, arm-near | gait 1 → 0 | Partial |

The exact `startPose`, `endPose`, duration and easing for each action are in `motion-catalog.json`.

## Contact choreography

The supplied V4 `interaction-catalog.json` includes a numerically solved front-view pair:

- Male near arm: `upper-arm-R = -9.64718599°`, `forearm-R = -65°`, `hand-R = -15.35281401°`.
- Female near arm: `upper-arm-L = 40.70562802°`, `forearm-L = 39°`, `hand-L = 10.29437198°`.
- Source stage: male x=225, female x=539.21874263; scales 0.7 and 0.73362329057; soles grounded at stage y=740. Source solution reports residual ~0 and a 2-pixel tolerance.
- Scene wraps **both actors** in one `translate(35 601) scale(1.1)` group. The 8-second test finishes contact at 6.85 seconds. Runtime checks world-space contact anchors against 2.2 scene pixels after contact.

**Scope:** This is a solved keyframe for a fixed pair layout. `touch` does not automatically move arbitrary actors together, solve IK, detect full mesh collisions or change authored arm lengths. These would require additional approved keyframes or explicit requirements.

## Limitations and integration

1. **Do not interpret the walk proxy as the approved walk-cycle sheet.** V4 retains walk reference images but lacks verified bound production SVG poses. This demo uses finite front-view leg/arm swings and root travel; it needs art review.
2. `lookAt` currently tilts the head, **not true eye tracking or yaw**. Do not synthesize a three-quarter pose by squashing front art.
3. Facial reactions use source-authored front expressions only. Switching is computed from absolute time during `seek`, not a `.call()`/`onComplete` callback.
4. The pair touch is visually and numerically reviewed in an offline Chromium harness. Full silhouette, forearm occlusion and production approval are still pending.
5. This deliverable **does not patch the Studio engine**. The sample Story ZIP follows the supplied contract; actual Studio import, GSAP 3.15.0 execution and MP4 export remain to be run in the user's Studio.
6. In the offline Chromium QA harness, the SVG DOM at the same time is byte-for-byte deterministic after forward/reverse/repeated seeks, but some screenshots differ by a small number of anti-aliased pixels after reverse seeks. The Story Studio exporter requires exact PNG hashes: **do not mark exporter acceptance passed** until tested in Studio. See `validation-report.md`.

## Open the deliverables

- `phase03-story-8s.zip`: import **this nested ZIP** into Story Studio, not the whole delivery ZIP.
- `motion-preview.html`: standalone offline review, play/reverse/scrub/contact overlay; uses the same scene/source logic but a pure-clock test adapter, not the Studio runtime.
- `qa/phase03-contact-sheet.png`: snapshots at 0, 2, 4, 6, 8 seconds.
