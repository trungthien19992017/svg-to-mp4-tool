# PHASE 03 — Validation Report

**Result:** Technical prototype created. **NOT approved for production or certified Studio integration.**

## Source inventory

- `character-pack-v4(2).zip`: two production SVGs, rig metadata, 12 front expressions per character, pose and interaction catalogs. The V4 report explicitly states Studio integration and actual GSAP 3.15.0 execution were **not run**, dynamic poses remain Partial.
- `rainy-room-environment-pack(1).zip`: Rain SVG V3 and the approved rainy-room composition. SMIL translations converted into pure-time SVG transforms for the Story ZIP; all original static vector geometry copied without redrawing.
- `animation-code-contract(5).md`: exact Studio `createScene(context)` signature and GSAP 3.15.0 timeline lifecycle.
- `demo-5(3).html`: legacy GSAP 3.12.2 browser demo; **not** used as the authoritative Studio API.

## Code/asset checks

| Check | Result | Scope |
|---|---|---|
| XML parse, local fragment references, unique SVG IDs | PASS | Production SVGs and derived environment assets, browser scene |
| Native SVG / no raster character substitution | PASS | V4 character SVGs copied byte-for-byte |
| 12 front expressions per actor | PASS | Authored V4 states, no invented new faces |
| Motion actions available | PASS | 13 action APIs (lookAt and headTilt separately) |
| Overlapping channel protection | PASS | Unit tests reject conflicting same-actor arm timelines |
| Timeline-only scene time | PASS (source review) | Single paused `context.timeline()` clock; no timers, callbacks or autonomous animation |
| Seek lifecycle and reset/dispose | PASS in offline harness | Synchronous seek and clean dispose; real Studio not run |
| Multi-instance SVG ID collision | PASS in offline harness | Two simultaneous scene instances in same canvas |
| Rain movement and clipping | PASS (source + browser) | 194 rain paths, source V3 pane masks; motion responds to seek |
| Joint-angle bounds | PASS in offline harness | All 0–8s sampled states rendered without joint-limit exceptions |
| Contact-anchor distance at 6.85s | PASS in offline harness | 0.0000123 scene px, threshold 2.2 px |
| Full mesh/silhouette occlusion | PARTIAL | Contact region inspected; no production-grade mesh collision test |
| Exact screenshot hash after reverse seek | **NOT PASSED** | Chromium anti-alias raster differences, despite exact DOM state |
| Actual Story Studio import/GSAP runtime | **NOT RUN** | Studio application/runtime not supplied or accessible |
| MP4 export/render | **NOT RUN** | Requires Studio/worker |

## Seek tests (offline Chromium)

All seek times were tested in order `0 → 2 → 4 → 6 → 8`, followed by `8 → 6 → 4 → 2 → 0`, then repeated seeks and non-grid times. All same-time SVG DOM serializations had matching SHA-256 hashes after reverse and repeated seeks. Values below are contact-anchor separations in **scene pixels**:

| t (s) | Hand distance (px) | Visual state | DOM seek |
|---:|---:|---|---|
| 0 | 270.214 | Male enters, female idle | PASS |
| 2 | 73.849 | Female surprised, male walking | PASS |
| 4 | 61.891 | Male stopped and smiling | PASS |
| 6 | 1.796 | Reaching, not yet final contact | PASS |
| 8 | 0.0000123 | Contact held, female touched | PASS |
| 6.85 | 0.0000123 | First full contact | PASS |

**Exact PNG issue:** On 440×783 preview captures, Chromium changed roughly 91–323 of 344,520 pixels after reverse seek (maximum channel delta 5–37 depending on sample), while the SVG DOM remained identical. These are small anti-alias/raster-cache differences, not a detected state drift. They are still an **exact-hash failure**. The official exporter probes exact PNG hashes; its outcome is unknown until run in Studio. Do not infer acceptance from the offline DOM test. A canvas display flush improved this locally but was deliberately **not** added to scene code because it would mutate engine-owned canvas visibility and could cause flicker or performance problems.

## Contact/grounding

- Both characters share a single stage transform, so their solved V4 contact anchors remain coincident under scaling.
- Male front `hand-R.contact` and female front `hand-L.contact` are checked after authored shoulder/elbow/wrist rotations.
- No runtime IK, physics, limb stretching, or root Y adjustment to force contact.
- The V4 source solution reports head-proxy clearance of 32.51 stage pixels; this is **not** a full contour collision guarantee.
- Front-view walking is a technical stand-in. The approved walk-cycle sheet has not been bound to the V4 rig. Final animation visual approval is required.

## Compatibility and requested next checks

1. Import `phase03-story-8s.zip` into the user's Story Studio and inspect 0, 2, 4, 6, 6.85 and 8 seconds.
2. Run Studio's actual GSAP 3.15.0 runtime and exporter seek-hash probe. Record pass/fail; do not alter the engine without a separate approved change request.
3. Review walk cycle, arm silhouette, elbow/hand occlusion and facial timing against approved sheets.
4. If the Studio exporter reproduces the PNG hash issue, raise a separate **renderer raster consistency** requirement, with reproducible frames and hashes, before changing Studio code.

**Status policy:** Only static poses that pass visual and structural QA can be marked `Supported`. No dynamic motion in this deliverable is marked `Supported`.
