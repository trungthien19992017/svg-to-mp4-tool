import {strict as assert} from 'node:assert';
import {createMotionComposer, actionChannels} from '../modules/motion-library.js';
import {RIG_DATA} from '../modules/rig-data.js';
const s=RIG_DATA.contactSolution;
const actors={male:{x:s.maleX,y:0,scale:s.scaleMale},female:{x:s.femaleX,y:0,scale:s.scaleFemale}};
const composer=createMotionComposer({duration:8,actors});
const ma={upper:s.male['upper-arm-R'],forearm:s.male['forearm-R'],hand:s.male['hand-R']};
const fa={upper:s.female['upper-arm-L'],forearm:s.female['forearm-L'],hand:s.female['hand-L']};
composer.add('walk','male',0,2.5,{fromX:-240,toX:s.maleX});
composer.add('stopWalking','male',2.5,.5,{});
composer.add('breathe','female',0,8,{});
composer.add('lookAt','female',1.2,.6,{from:0,to:-5});
composer.add('surprisedReaction','female',1.8,.75,{});
composer.add('happyReaction','male',3.05,.7,{});
composer.add('reach','male',4.45,1.85,{arm:'R',targetAngles:ma});
composer.add('reach','female',4.45,1.85,{arm:'L',targetAngles:fa});
composer.add('touch','male',6.3,.55,{arm:'R',targetAngles:ma});
composer.add('touch','female',6.3,.55,{arm:'L',targetAngles:fa});
composer.add('blink','male',7.4,.25,{});
composer.finalize();
const keyTimes=[0,2,4,6,8];
const snapshots=keyTimes.map(t=>JSON.stringify(composer.evaluate(t)));
for(const t of [8,6,4,2,0,8,0,2,4,6,8,3.23,1.81,6.85]){
  const snapshot=JSON.stringify(composer.evaluate(t));
  if(keyTimes.includes(t))assert.equal(snapshot,snapshots[keyTimes.indexOf(t)],'seek order changed '+t);
}
const end=composer.evaluate(8);
assert.equal(end.male.x,s.maleX);
assert.equal(end.male.gait,0);
assert.equal(end.female.expression,'surprised');
assert.equal(end.male.armR.forearm,ma.forearm);
assert.equal(end.female.armL.upper,fa.upper);
assert.equal(composer.evaluate(0).male.x,-240);
assert.equal(actionChannels('touch')[0],'arm-near');
let blocked=false;
try {const c=createMotionComposer({duration:8,actors});c.add('reach','male',1,2,{arm:'R',targetAngles:ma});c.add('touch','male',2,1,{arm:'R',targetAngles:ma});}catch(e){blocked=/Conflicting motion channels/.test(e.message)}
assert.equal(blocked,true,'overlap guard must reject same arm channel');
for(const type of ['idle','blink','breathe','lookAt','headTilt','happyReaction','surprisedReaction','sadReaction','reach','touch','release','walk','stopWalking'])assert.ok(actionChannels(type).length);
// Exercise each action's actual evaluator branch, not just its public name.
const specs = {
 idle:{}, blink:{}, breathe:{}, lookAt:{from:0,to:3}, headTilt:{from:0,to:3},
 happyReaction:{}, surprisedReaction:{}, sadReaction:{},
 reach:{arm:'R',targetAngles:ma}, touch:{arm:'R',targetAngles:ma},
 release:{arm:'R',targetAngles:ma}, walk:{fromX:0,toX:20}, stopWalking:{}
};
for(const [type,options] of Object.entries(specs)){
 const c=createMotionComposer({duration:3,actors});
 c.add(type,'male',.2,1.2,options);
 c.finalize();
 for(const t of [0,.2,.5,1.4,3]){
  const state=c.evaluate(t).male;
  assert.ok(Number.isFinite(state.x));
  assert.ok(Number.isFinite(state.headRotation));
  assert.ok(Number.isFinite(state.gait));
  assert.ok(Number.isFinite(state.armR.forearm));
 }
}
console.log('PASS: all 13 action evaluators; deterministic arbitrary seeks; forward/backward/repeat; channel collision guard; final arm angles');
