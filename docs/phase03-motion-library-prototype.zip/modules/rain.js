/** Exact V3 rain geometry, SMIL timings converted to absolute scene time. */
export function createDeterministicRain(svgGroup) {
    const drops = [];
    for (const node of svgGroup.querySelectorAll('[data-rain-duration]')) {
        const from = node.getAttribute('data-rain-from').split(',').map(Number);
        const to = node.getAttribute('data-rain-to').split(',').map(Number);
        const duration = Number(node.getAttribute('data-rain-duration'));
        const begin = Number(node.getAttribute('data-rain-begin'));
        if (!from.every(Number.isFinite) || !to.every(Number.isFinite) ||
            !Number.isFinite(duration) || duration <= 0 || !Number.isFinite(begin)) {
            throw new Error('Invalid V3 rain metadata');
        }
        drops.push({node, from, to, duration, begin});
    }
    function seek(time) {
        for (const drop of drops) {
            const phase = (((time - drop.begin) % drop.duration) + drop.duration) % drop.duration / drop.duration;
            const x = drop.from[0] + (drop.to[0] - drop.from[0]) * phase;
            const y = drop.from[1] + (drop.to[1] - drop.from[1]) * phase;
            drop.node.setAttribute('transform', 'translate(' + x.toFixed(4) + ' ' + y.toFixed(4) + ')');
        }
    }
    return {seek, count: drops.length};
}
