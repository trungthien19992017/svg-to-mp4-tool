/** Fragment-only SVG ID namespacing. No engine or Studio global mutations. */
const reserved = new Set();
export function namespaceSvg(markup, requested) {
    const safe = String(requested).replace(/[^a-zA-Z0-9_-]/g, '-');
    let prefix = safe;
    for (let index = 2; reserved.has(prefix); index++) prefix = safe + '-' + index;
    reserved.add(prefix);
    const parsed = new DOMParser().parseFromString(markup, 'image/svg+xml');
    if (parsed.querySelector('parsererror') || parsed.documentElement.localName !== 'svg') {
        reserved.delete(prefix);
        throw new Error('Invalid SVG asset: ' + requested);
    }
    const idMap = new Map();
    for (const element of parsed.querySelectorAll('[id]')) {
        const original = element.getAttribute('id');
        if (idMap.has(original)) throw new Error('Duplicate source SVG ID ' + original);
        idMap.set(original, prefix + '--' + original);
    }
    for (const element of parsed.querySelectorAll('*')) {
        for (const attribute of [...element.attributes]) {
            let value = attribute.value;
            if (attribute.name === 'id') value = idMap.get(value);
            else {
                value = value.replace(/url\(\s*['"]?#([^\s)'";]+)['"]?\s*\)/g,
                    (all, id) => idMap.has(id) ? 'url(#' + idMap.get(id) + ')' : all);
                if ((attribute.localName === 'href') && value.startsWith('#')) {
                    value = '#' + (idMap.get(value.slice(1)) || value.slice(1));
                }
            }
            if (value !== attribute.value) element.setAttribute(attribute.name, value);
        }
    }
    return {
        markup: new XMLSerializer().serializeToString(parsed.documentElement),
        prefix,
        release() { reserved.delete(prefix); }
    };
}
