import {RIG_DATA} from './rig-data.js';

const PARTS = ['root', 'torso', 'neck', 'head', 'upper-arm-L', 'forearm-L', 'hand-L',
    'upper-arm-R', 'forearm-R', 'hand-R', 'thigh-L', 'shin-L', 'foot-L',
    'thigh-R', 'shin-R', 'foot-R'];
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/** Original V4 vector nodes are never redrawn. Only authored group transforms change. */
export function createActor(group, sex, layout) {
    const rig = RIG_DATA[sex];
    if (!rig) throw new Error('Missing source rig: ' + sex);
    const views = [...group.children].filter(node => node.hasAttribute('data-view'));
    const front = views.find(node => node.getAttribute('data-view') === 'front');
    if (!front) throw new Error(sex + ': front view is required for verified source anchors');
    const nodes = {};
    for (const name of PARTS) {
        const found = front.querySelector('[data-part="' + name + '"]');
        if (!found) throw new Error(sex + ': missing rig node ' + name);
        nodes[name] = found;
    }
    const expressions = [...front.querySelectorAll('[data-expression]')];
    const expressionIds = new Set(expressions.map(node => node.getAttribute('data-expression')));
    if (expressionIds.size !== 12) throw new Error(sex + ': expected exactly 12 front expressions');
    const eyeNodes = [];
    for (const expr of expressions) {
        for (const eye of expr.querySelectorAll('[data-blink-pivot]')) {
            const pivot = eye.getAttribute('data-blink-pivot').trim().split(/\s+/).map(Number);
            if (pivot.length !== 2 || !pivot.every(Number.isFinite)) throw new Error('Bad blink pivot');
            eyeNodes.push({eye, pivot, closed: expr.getAttribute('data-closed-eyes') === 'true'});
        }
    }
    const pose = {x: layout.x, y: layout.y, scale: layout.scale};
    function render(state) {
        for (const view of views) view.setAttribute('visibility', view === front ? 'visible' : 'hidden');
        const selected = expressionIds.has(state.expression) ? state.expression : 'default';
        for (const expr of expressions) expr.setAttribute('visibility', expr.getAttribute('data-expression') === selected ? 'visible' : 'hidden');
        const closure = clamp(state.blink || 0, 0, 1);
        for (const item of eyeNodes) {
            const [x, y] = item.pivot;
            const sy = item.closed ? 1 : 1 - closure * 0.96;
            item.eye.setAttribute('transform', 'translate(' + x + ' ' + y + ') scale(1 ' + sy + ') translate(' + -x + ' ' + -y + ')');
        }
        const gait = clamp(state.gait || 0, 0, 1);
        const phase = (state.gaitTime || 0) * Math.PI * 2 * 1.6;
        const swing = Math.sin(phase) * gait;
        const liftL = Math.max(0, Math.sin(phase)) * gait;
        const liftR = Math.max(0, -Math.sin(phase)) * gait;
        const rotations = {
            'head': state.headRotation || 0,
            'upper-arm-L': (state.armL?.upper || 0) + swing * 9,
            'forearm-L': state.armL?.forearm || 0,
            'hand-L': state.armL?.hand || 0,
            'upper-arm-R': (state.armR?.upper || 0) - swing * 9,
            'forearm-R': state.armR?.forearm || 0,
            'hand-R': state.armR?.hand || 0,
            'thigh-L': swing * 16,
            'shin-L': -liftL * 18,
            'foot-L': -swing * 6,
            'thigh-R': -swing * 16,
            'shin-R': -liftR * 18,
            'foot-R': swing * 6
        };
        for (const name of PARTS) {
            const data = rig.nodes[name];
            const [mx, my] = data.mount;
            const angle = rotations[name] || 0;
            if (angle < data.limits[0] - 0.0001 || angle > data.limits[1] + 0.0001) {
                throw new Error(sex + ' joint limit: ' + name + ' = ' + angle);
            }
            const dy = name === 'torso' ? (state.bodyY || 0) :
                name === 'neck' ? (state.neckY || 0) :
                name === 'head' ? (state.headY || 0) : 0;
            nodes[name].setAttribute('transform', 'translate(' + mx + ' ' + (my + dy) + ') rotate(' + angle + ')');
        }
        group.setAttribute('transform', 'translate(' + state.x + ' ' + pose.y + ') scale(' + pose.scale + ')');
    }
    function anchorWorld(partName, anchorName) {
        const anchor = rig.nodes[partName]?.anchors[anchorName];
        const part = nodes[partName];
        if (!anchor || !part) throw new Error('Missing contact anchor ' + sex + ':' + partName + '.' + anchorName);
        const matrix = part.getCTM();
        if (!matrix) throw new Error('Unattached actor');
        const point = new DOMPoint(anchor[0], anchor[1]).matrixTransform(matrix);
        return {x: point.x, y: point.y};
    }
    return {sex, group, rig, layout: pose, render, anchorWorld, expressions: [...expressionIds],
        dispose() { group.remove(); }};
}
