import {namespaceSvg} from '../modules/svg-namespace.js';
import {createActor} from '../modules/actor.js';
import {RIG_DATA} from '../modules/rig-data.js';
import {createMotionComposer, createTimelineMotion} from '../modules/motion-library.js';
import {createDeterministicRain} from '../modules/rain.js';

// Story Studio's exact named entrypoint; no engine patching, no timers or callbacks.
export function createScene(context) {
    if (!context.gsap || !context.timeline || !context.assetText || !context.addSvg) {
        throw new Error('Story Animation Contract v1 context required');
    }
    const duration = 8;
    const mounted = [];
    const namespaces = [];
    const rainControllers = [];
    const add = (id, parent = undefined) => {
        const source = namespaceSvg(context.assetText(id), context.sceneId + '-' + id);
        namespaces.push(source);
        const group = context.addSvg(source.markup, parent ? {parent} : {});
        mounted.push(group);
        return group;
    };
    const env = id => add(id);
    env('background-far');
    rainControllers.push(createDeterministicRain(env('rain-back')));
    env('walls');
    rainControllers.push(createDeterministicRain(env('rain-glass')));
    env('window-reflections');
    env('floor');
    env('furniture');

    // Source V4 contact solution is in 940 x 795 stage coordinates.
    // Single shared scene-space transform preserves the solved anchors and grounded soles.
    const stage = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    stage.setAttribute('data-stage', 'character-stage');
    stage.setAttribute('transform', 'translate(35 601) scale(1.1)');
    context.canvas.appendChild(stage);
    mounted.push(stage);
    const solution = RIG_DATA.contactSolution;
    const maleY = solution.floorY - RIG_DATA.male.soleY * solution.scaleMale;
    const femaleY = solution.floorY - RIG_DATA.female.soleY * solution.scaleFemale;
    const maleGroup = add('male-art', stage);
    const femaleGroup = add('female-art', stage);
    const male = createActor(maleGroup, 'male', {x:solution.maleX, y:maleY, scale:solution.scaleMale});
    const female = createActor(femaleGroup, 'female', {x:solution.femaleX, y:femaleY, scale:solution.scaleFemale});
    env('foreground');
    env('lighting');

    const composer = createMotionComposer({duration, gsap:context.gsap,
        actors: {male:{x:solution.maleX, y:maleY, scale:solution.scaleMale},
                 female:{x:solution.femaleX, y:femaleY, scale:solution.scaleFemale}}});
    const mTarget = solution.male;
    const fTarget = solution.female;
    const mAngles = {upper:mTarget['upper-arm-R'], forearm:mTarget['forearm-R'], hand:mTarget['hand-R']};
    const fAngles = {upper:fTarget['upper-arm-L'], forearm:fTarget['forearm-L'], hand:fTarget['hand-L']};
    // The choreography is provisional; all motion channels are exclusive per actor.
    composer.add('walk', 'male', 0, 2.5, {id:'male-enter', fromX:-240, toX:solution.maleX, ramp:.13, easing:'sine.inOut'});
    composer.add('stopWalking', 'male', 2.5, .5, {id:'male-stop', fromGait:1, easing:'sine.inOut'});
    composer.add('idle', 'female', 0, 1.2, {id:'female-idle', amplitude:1.2, cycles:1});
    composer.add('breathe', 'female', 0, 8, {id:'female-breathe', amplitude:1.2, period:2.7});
    composer.add('breathe', 'male', 3, 5, {id:'male-breathe', amplitude:1.2, period:2.7});
    composer.add('lookAt', 'female', 1.2, .6, {id:'female-look-left', from:0, to:-5});
    composer.add('surprisedReaction', 'female', 1.8, .75, {id:'female-surprise', expression:'surprised', fromY:0, toY:-5});
    composer.add('happyReaction', 'male', 3.05, .7, {id:'male-smile', expression:'pleased', fromY:0, toY:-2});
    composer.add('headTilt', 'male', 3.75, .55, {id:'male-tilt', from:0, to:4});
    composer.add('reach', 'male', 4.45, 1.85, {id:'male-reach', arm:'R', targetAngles:mAngles, fromFactor:0, toFactor:.92, easing:'sine.inOut'});
    composer.add('reach', 'female', 4.45, 1.85, {id:'female-reach', arm:'L', targetAngles:fAngles, fromFactor:0, toFactor:.92, easing:'sine.inOut'});
    composer.add('touch', 'male', 6.3, .55, {id:'male-contact', arm:'R', targetAngles:mAngles, fromFactor:.92, toFactor:1, easing:'sine.inOut'});
    composer.add('touch', 'female', 6.3, .55, {id:'female-contact', arm:'L', targetAngles:fAngles, fromFactor:.92, toFactor:1, easing:'sine.inOut'});
    composer.add('happyReaction', 'female', 6.95, .5, {id:'female-touched', expression:'touched', fromY:-5, toY:-1});
    for (const [who, t] of [['female',.72], ['female',2.7], ['male',3.92], ['female',5.1], ['male',7.48]]) {
        composer.add('blink', who, t, .24, {id:who+'-blink-'+t, easing:'sine.inOut'});
    }
    composer.finalize();
    const timelineMotion = createTimelineMotion(context, composer, (state, time) => {
        male.render(state.male);
        female.render(state.female);
        for (const rain of rainControllers) rain.seek(time);
        if (time >= 6.85 - 1e-6) {
            const m = male.anchorWorld('hand-R', 'contact');
            const f = female.anchorWorld('hand-L', 'contact');
            const distance = Math.hypot(m.x - f.x, m.y - f.y);
            if (distance > solution.toleranceStagePx * 1.1) {
                throw new Error('Hand contact outside authored 2px tolerance: ' + distance);
            }
        }
    });
    // Optional QA access for offline harness. No Studio API is invented.
    const debug = {contact() {
        const m = male.anchorWorld('hand-R','contact');
        const f = female.anchorWorld('hand-L','contact');
        return {male:m, female:f, distance:Math.hypot(m.x-f.x,m.y-f.y)};
    }, get actions() {return composer.actions;}, sample:t=>composer.evaluate(t)};
    context.canvas.__phase03Debug = debug;
    let disposed = false;
    return {
        duration,
        seek(time) {if (!disposed) timelineMotion.seek(time);},
        reset() {if (!disposed) timelineMotion.reset();},
        dispose() {
            if (disposed) return;
            disposed = true;
            timelineMotion.dispose();
            for (const group of mounted.slice().reverse()) group.remove();
            for (const source of namespaces) source.release();
            if (context.canvas.__phase03Debug === debug) delete context.canvas.__phase03Debug;
        }
    };
}
