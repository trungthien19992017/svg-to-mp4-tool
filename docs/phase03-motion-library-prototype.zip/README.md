# Phase 03 — Reusable GSAP Motion Library (8s Prototype)

**Start here:**

- `motion-preview.html`: open in Chrome or Edge to review the animation without a server. The file embeds its own assets and motion code; no CDN.
- `phase03-story-8s.zip`: import this **nested Story ZIP** into SVG Storyboard Animation Studio.
- `modules/motion-library.js`: reusable motion source. See `MOTION-API.md` and `motion-catalog.json`.
- `validation-report.md`: test results and explicit limitations.
- `qa/phase03-contact-sheet.png`: five key-time frames.

The Story ZIP is contract-shaped and self-contained, but actual Studio import and MP4 export have not been run. Walk/reach/touch are technical prototypes pending approval of bound motion artwork. The original V4 robot SVG files have not been modified.
