Demo only. Storytelling rules are not executed.
