Bản thử front của hai robot dùng artwork thật. Không có tương tác tiếp xúc, đi bộ hoặc góc nhìn khác. Các chuyển động mới chỉ để kiểm tra khớp; không phải motion đã được duyệt.
