export function evaluate(t,duration) {return {head:3*Math.sin(Math.PI*t/duration)};}
