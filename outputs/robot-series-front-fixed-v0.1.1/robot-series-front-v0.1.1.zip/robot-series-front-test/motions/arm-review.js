export function evaluate(t,duration) {return {"upper-arm-R":-6*Math.sin(Math.PI*t/duration),"forearm-R":-4*Math.sin(Math.PI*t/duration)};}
