// Shared helpers for the robot episode. Pure functions of time: no tweens, no runtime globals.
// Element lookup uses data-view / data-part / data-expression, never id (Studio namespaces ids).

const SVG_NS = 'http://www.w3.org/2000/svg';

// Mounts and joint limits from the approved V4 rig (pair-calibrated-v2).
export const RIG = {"male": {"head": {"mount": [0, 0], "limits": [-15, 15]}, "neck": {"mount": [0, -103], "limits": [-180, 180]}, "torso": {"mount": [232, 485], "limits": [-180, 180]}, "upper-arm-L": {"mount": [-80, -72], "limits": [-70, 70]}, "forearm-L": {"mount": [-27.04, 75.4], "limits": [-65, 65]}, "hand-L": {"mount": [-24.96, 69.6], "limits": [-30, 30]}, "upper-arm-R": {"mount": [80, -72], "limits": [-70, 70]}, "forearm-R": {"mount": [27.04, 75.4], "limits": [-65, 65]}, "hand-R": {"mount": [24.96, 69.6], "limits": [-30, 30]}}, "female": {"head": {"mount": [0, 0], "limits": [-15, 15]}, "neck": {"mount": [0, -82], "limits": [-180, 180]}, "torso": {"mount": [223, 521], "limits": [-180, 180]}, "upper-arm-L": {"mount": [-75, -56], "limits": [-70, 70]}, "forearm-L": {"mount": [-21.32, 54.6], "limits": [-65, 65]}, "hand-L": {"mount": [-19.68, 50.4], "limits": [-30, 30]}, "upper-arm-R": {"mount": [75, -56], "limits": [-70, 70]}, "forearm-R": {"mount": [21.32, 54.6], "limits": [-65, 65]}, "hand-R": {"mount": [19.68, 50.4], "limits": [-30, 30]}}};

// Calibrated contact angles from the approved reference (scene-002 contactSolution).
export const CONTACT = {
  female: { upper: 40.70562802469823, forearm: 39, hand: 10.294371975301772 },
  male: { upper: -9.647185987650886, forearm: -65, hand: -15.352814012349114 },
};

export const STAGE_TRANSFORM = 'translate(-66.713779096 601.000000000) scale(1.1)';
export const POSE = {
  male: { x: 225, y: 238.45, s: 0.7 },
  female: { x: 539.2187426275393, y: 218.76065205131817, s: 0.7336232905681658 },
};

const ENV_BACK = ['background-far', 'rain-back', 'walls', 'rain-glass', 'window-reflections', 'floor', 'furniture'];
const ENV_FRONT = ['foreground', 'lighting'];

// Sine ease-in-out keyframes. frames = [[time, value], ...]. Holds before first and after last.
export function key(t, frames) {
  if (t <= frames[0][0]) return frames[0][1];
  for (let i = 0; i < frames.length - 1; i++) {
    const [t0, v0] = frames[i];
    const [t1, v1] = frames[i + 1];
    if (t <= t1) {
      const u = (t - t0) / (t1 - t0);
      return v0 + (v1 - v0) * (-(Math.cos(Math.PI * u) - 1) / 2);
    }
  }
  return frames[frames.length - 1][1];
}

// Step expression: list = [[time, id], ...]; returns the latest id whose time has passed.
export function exprAt(t, list) {
  let id = list[0][1];
  for (const [t0, v] of list) if (t >= t0) id = v;
  return id;
}

// Show exactly one authored expression in the front view.
export function setExpr(group, id) {
  group.querySelectorAll('[data-view="front"] [data-expression]').forEach((n) => {
    n.style.display = n.getAttribute('data-expression') === id ? '' : 'none';
  });
}

// Rotate one rig part in the front view. dy lifts a part (used for head bob).
export function setPart(group, sex, part, angle, dy = 0) {
  const data = RIG[sex] && RIG[sex][part];
  if (!data) throw new Error(sex + ': no rig data for ' + part);
  if (angle < data.limits[0] - 1e-4 || angle > data.limits[1] + 1e-4) {
    throw new Error(sex + ' joint limit: ' + part + ' = ' + angle);
  }
  const node = group.querySelector('[data-view="front"] [data-part="' + part + '"]');
  if (!node) throw new Error(sex + ': missing front part ' + part);
  const [mx, my] = data.mount;
  node.setAttribute('transform', 'translate(' + mx + ' ' + (my + dy) + ') rotate(' + angle + ')');
}

export function placeChar(group, pose, x = pose.x) {
  group.setAttribute('transform', 'translate(' + x + ' ' + pose.y + ') scale(' + pose.s + ')');
}

export function setCamera(context, c) {
  context.camera.x = c.x;
  context.camera.y = c.y;
  context.camera.scale = c.scale;
  context.camera.rotation = c.rotation || 0;
}

// Namespace SVG ids per asset so scenes do not collide (same approach as the reference).
const reserved = new Set();
function namespaceSvg(markup, requested) {
  const safe = String(requested).replace(/[^a-zA-Z0-9_-]/g, '-');
  let prefix = safe;
  for (let index = 2; reserved.has(prefix); index++) prefix = safe + '-' + index;
  reserved.add(prefix);
  const parsed = new DOMParser().parseFromString(markup, 'image/svg+xml');
  if (parsed.querySelector('parsererror') || parsed.documentElement.localName !== 'svg') {
    reserved.delete(prefix);
    throw new Error('Invalid SVG asset: ' + requested);
  }
  const idMap = new Map();
  for (const element of parsed.querySelectorAll('[id]')) {
    const original = element.getAttribute('id');
    if (idMap.has(original)) throw new Error('Duplicate source SVG ID ' + original);
    idMap.set(original, prefix + '--' + original);
  }
  for (const element of parsed.querySelectorAll('*')) {
    for (const attribute of [...element.attributes]) {
      let value = attribute.value;
      if (attribute.name === 'id') value = idMap.get(value);
      else {
        value = value.replace(/url\(\s*['"]?#([^\s)'";]+)['"]?\s*\)/g,
          (all, id) => (idMap.has(id) ? 'url(#' + idMap.get(id) + ')' : all));
        if (attribute.localName === 'href' && value.startsWith('#')) {
          value = '#' + (idMap.get(value.slice(1)) || value.slice(1));
        }
      }
      if (value !== attribute.value) element.setAttribute(attribute.name, value);
    }
  }
  return new XMLSerializer().serializeToString(parsed.documentElement);
}

// Builds environment, stage and both robots. Returns handles used by the scene's render().
export function buildStage(context, globalStart) {
  const sceneRoot = context.addSvg('<svg xmlns="' + SVG_NS + '"><g/></svg>');
  const add = (id, parent) => {
    const markup = namespaceSvg(context.assetText(id), context.sceneId + '-' + id);
    return context.addSvg(markup, { parent: parent || sceneRoot });
  };
  const rain = [];
  for (const id of ENV_BACK) {
    const g = add(id);
    g.querySelectorAll('[data-rain-duration]').forEach((n) => rain.push(n));
  }
  const stage = document.createElementNS(SVG_NS, 'g');
  stage.setAttribute('transform', STAGE_TRANSFORM);
  sceneRoot.appendChild(stage);
  const male = add('robot-male', stage);
  const female = add('robot-female', stage);
  for (const id of ENV_FRONT) add(id);
  return { male, female, rain, globalStart };
}

// Rain falls on absolute global time, same formula as the reference.
export function rainSeek(nodes, globalTime) {
  for (const node of nodes) {
    const origin = node.getAttribute('data-rain-from').split(',').map(Number);
    const to = node.getAttribute('data-rain-to').split(',').map(Number);
    const duration = Number(node.getAttribute('data-rain-duration'));
    const begin = Number(node.getAttribute('data-rain-begin'));
    const phase = ((((globalTime - begin) % duration) + duration) % duration) / duration;
    const x = origin[0] + (to[0] - origin[0]) * phase;
    const y = origin[1] + (to[1] - origin[1]) * phase;
    node.setAttribute('transform', 'translate(' + x.toFixed(4) + ' ' + y.toFixed(4) + ')');
  }
}
