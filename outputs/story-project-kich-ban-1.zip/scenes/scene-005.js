import { buildStage, key, setExpr, setPart, placeChar, setCamera, rainSeek, POSE } from '../modules/kit.js';

// Outro 25–30s: both pleased/cheerful, female tilts toward male. No lean-on-shoulder artwork in the kit.
export function createScene(context) {
  const s = buildStage(context, 25);
  const render = (t) => {
    placeChar(s.male, POSE.male);
    placeChar(s.female, POSE.female);
    setExpr(s.male, 'pleased');
    setExpr(s.female, 'cheerful');
    setPart(s.female, 'female', 'head', key(t, [[0.8, 0], [2.3, 10]]));
    setCamera(context, {
      x: 0,
      y: 0,
      scale: key(t, [[0, 1], [5, 1.04]]),
    });
    rainSeek(s.rain, s.globalStart + t);
  };
  return {
    duration: 5,
    seek(time) { render(time); },
    reset() { render(0); },
    dispose() {},
  };
}
