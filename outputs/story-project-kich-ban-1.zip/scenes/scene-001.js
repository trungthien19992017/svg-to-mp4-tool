import { buildStage, key, exprAt, setExpr, setPart, placeChar, setCamera, rainSeek, POSE } from '../modules/kit.js';

// Hook 0–3s: female loving, male loving (Partial) and tilts head. Slow push-in from the first frame.
export function createScene(context) {
  const s = buildStage(context, 0);
  const render = (t) => {
    placeChar(s.male, POSE.male);
    placeChar(s.female, POSE.female);
    setExpr(s.male, exprAt(t, [[0, 'loving']]));
    setExpr(s.female, exprAt(t, [[0, 'loving']]));
    setPart(s.male, 'male', 'head', key(t, [[1.15, 0], [1.6, 4]]));
    setPart(s.female, 'female', 'head', 0);
    setCamera(context, {
      x: key(t, [[0, 0], [3, -20]]),
      y: key(t, [[0, 0], [3, -10]]),
      scale: key(t, [[0, 1], [3, 1.08]]),
    });
    rainSeek(s.rain, s.globalStart + t);
  };
  return {
    duration: 3,
    seek(time) { render(time); },
    reset() { render(0); },
    dispose() {},
  };
}
