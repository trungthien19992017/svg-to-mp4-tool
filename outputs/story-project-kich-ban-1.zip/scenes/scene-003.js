import { buildStage, key, exprAt, setExpr, setPart, placeChar, setCamera, rainSeek, POSE } from '../modules/kit.js';

// Climax 10–18s: male shy then touched, steps toward female (x-slide; no leg gait), heads tilt.
export function createScene(context) {
  const s = buildStage(context, 10);
  const render = (t) => {
    placeChar(s.male, POSE.male, POSE.male.x + key(t, [[0, 0], [3, 60]]));
    placeChar(s.female, POSE.female);
    setExpr(s.male, exprAt(t, [[0, 'shy'], [4.5, 'touched']]));
    setExpr(s.female, 'shy');
    setPart(s.male, 'male', 'head', key(t, [[2.1, 0], [2.7, -5]]));
    setPart(s.female, 'female', 'head', key(t, [[3.4, 0], [4.0, 4]]));
    setCamera(context, {
      x: key(t, [[0, 0], [8, 104]]),
      y: key(t, [[0, 0], [8, -46]]),
      scale: key(t, [[0, 1], [8, 1.15]]),
    });
    rainSeek(s.rain, s.globalStart + t);
  };
  return {
    duration: 8,
    seek(time) { render(time); },
    reset() { render(0); },
    dispose() {},
  };
}
