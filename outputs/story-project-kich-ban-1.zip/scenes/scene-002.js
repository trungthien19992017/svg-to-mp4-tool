import { buildStage, key, setExpr, setPart, placeChar, setCamera, rainSeek, POSE, CONTACT } from '../modules/kit.js';

// Contact 3–10s: female (L arm) and male (R arm) reach to the calibrated contact angles.
export function createScene(context) {
  const s = buildStage(context, 3);
  const render = (t) => {
    placeChar(s.male, POSE.male);
    placeChar(s.female, POSE.female);
    setExpr(s.male, 'default');
    setExpr(s.female, 'shy');

    const fReach = key(t, [[0.5, 0], [2.8, 0.82]]);
    const mReach = key(t, [[1.8, 0], [3.8, 0.82]]);
    setPart(s.female, 'female', 'upper-arm-L', CONTACT.female.upper * fReach);
    setPart(s.female, 'female', 'forearm-L', CONTACT.female.forearm * fReach);
    setPart(s.female, 'female', 'hand-L', CONTACT.female.hand * fReach);
    setPart(s.male, 'male', 'upper-arm-R', CONTACT.male.upper * mReach);
    setPart(s.male, 'male', 'forearm-R', CONTACT.male.forearm * mReach);
    setPart(s.male, 'male', 'hand-R', CONTACT.male.hand * mReach);

    setCamera(context, {
      x: key(t, [[2.5, 0], [5.5, 5]]),
      y: key(t, [[2.5, 0], [5.5, -292]]),
      scale: key(t, [[2.5, 1], [5.5, 1.08]]),
    });
    rainSeek(s.rain, s.globalStart + t);
  };
  return {
    duration: 7,
    seek(time) { render(time); },
    reset() { render(0); },
    dispose() {},
  };
}
