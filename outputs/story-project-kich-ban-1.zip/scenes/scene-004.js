import { buildStage, key, exprAt, setExpr, setPart, placeChar, setCamera, rainSeek, POSE } from '../modules/kit.js';

// Twist 18–25s: piano cut and sting are in the audio manifest. Male surprised (head lifts),
// female reaches (gesture; no invoice prop in the kit), snap zoom onto the male's face.
export function createScene(context) {
  const s = buildStage(context, 18);
  const render = (t) => {
    placeChar(s.male, POSE.male);
    placeChar(s.female, POSE.female);
    setExpr(s.male, exprAt(t, [[0, 'touched'], [0.65, 'surprised']]));
    setExpr(s.female, 'cheerful');
    setPart(s.male, 'male', 'head', 0, key(t, [[0.65, 0], [1.55, -7]]));
    setPart(s.female, 'female', 'upper-arm-R', key(t, [[0.5, 0], [1.5, -25]]));
    setPart(s.female, 'female', 'forearm-R', key(t, [[1.0, 0], [1.8, -15]]));
    setCamera(context, {
      x: key(t, [[0, 0], [0.3, 235], [2.5, 235], [3.2, 0]]),
      y: key(t, [[0, 0], [0.3, -82], [2.5, -82], [3.2, 0]]),
      scale: key(t, [[0, 1], [0.3, 1.3], [2.5, 1.3], [3.2, 1]]),
    });
    rainSeek(s.rain, s.globalStart + t);
  };
  return {
    duration: 7,
    seek(time) { render(time); },
    reset() { render(0); },
    dispose() {},
  };
}
