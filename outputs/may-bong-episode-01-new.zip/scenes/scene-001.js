export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('bedroom'));
  context.addSvg(context.assetText('bed'));
  context.addSvg(context.assetText('lamp'));
  const may = context.character('may', {id:'may-actor',x:185,y:1030,scale:2.35});
  const bong = context.character('bong', {id:'bong-actor',x:580,y:1100,scale:1.92});
  context.addSvg(context.assetText('blanket'));
  const m = id => may.querySelector('#'+id);
  const b = id => bong.querySelector('#'+id);
  const t = context.timeline();
  const move = (el,from,to,at) => t.fromTo(el,from,to,at);
  const blink = (el,at) => move(el,{scaleY:1},{scaleY:0.08,transformOrigin:'center center',duration:.12,repeat:1,yoyo:true,ease:'power1.inOut'},at);
  const rotate = (el,a,z,at,d=.5) => move(el,{rotation:a},{rotation:z,transformOrigin:'50% 15%',duration:d,ease:'sine.inOut'},at);
  move(bong,{x:580,y:1110},{x:572,y:1094,duration:1.3,ease:'sine.inOut'},.7);
  rotate(b('head'),8,-7,1.1,.7); rotate(b('left-ear'),0,-10,.7,.35);
  blink(b('eyes'),.45); blink(b('eyes'),2.3);
  rotate(m('head'),-4,9,2.5,.65);
  move(context.camera,{scale:1,x:0,y:0},{scale:1.018,x:-8,y:-10,duration:4,ease:'sine.inOut'},0);
  return {duration:4,seek(time){t.time(time,true);},reset(){t.pause(0);},dispose(){t.kill();}};
}
