export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('bedroom'));
  context.addSvg(context.assetText('bed'));
  context.addSvg(context.assetText('lamp'));
  const may = context.character('may', {id:'may-actor',x:185,y:1030,scale:2.35});
  const bong = context.character('bong', {id:'bong-actor',x:580,y:1100,scale:1.92});
  context.addSvg(context.assetText('blanket'));
  const m = id => may.querySelector('#'+id);
  const b = id => bong.querySelector('#'+id);
  const t = context.timeline();
  const move = (el,from,to,at) => t.fromTo(el,from,to,at);
  const blink = (el,at) => move(el,{scaleY:1},{scaleY:0.08,transformOrigin:'center center',duration:.12,repeat:1,yoyo:true,ease:'power1.inOut'},at);
  const rotate = (el,a,z,at,d=.5) => move(el,{rotation:a},{rotation:z,transformOrigin:'50% 15%',duration:d,ease:'sine.inOut'},at);
  t.set(bong,{x:455,y:1084}); t.set(b('left-arm'),{rotation:-32,transformOrigin:'50% 15%'});
  t.set(b('right-arm'),{rotation:25,transformOrigin:'50% 15%'});
  rotate(b('left-arm'),-32,-73,.5,.55); rotate(b('right-arm'),25,67,1,.6);
  move(bong,{x:455,y:1084},{x:418,y:1081,duration:.75,ease:'power2.out'},1.2);
  rotate(b('head'),12,-20,2.2,.65);
  move(b('eyes'),{scaleY:1},{scaleY:.10,transformOrigin:'center center',duration:.35,ease:'sine.inOut'},3.1);
  rotate(m('head'),9,20,4.1,.45); blink(m('eyes'),5.1);
  move(context.camera,{scale:1.035,x:-14,y:-20},{scale:1.07,x:-32,y:-42,duration:6,ease:'sine.inOut'},0);
  return {duration:6,seek(time){t.time(time,true);},reset(){t.pause(0);},dispose(){t.kill();}};
}
