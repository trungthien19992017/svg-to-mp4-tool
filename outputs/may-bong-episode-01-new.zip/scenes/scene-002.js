export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('bedroom'));
  context.addSvg(context.assetText('bed'));
  context.addSvg(context.assetText('lamp'));
  const may = context.character('may', {id:'may-actor',x:185,y:1030,scale:2.35});
  const bong = context.character('bong', {id:'bong-actor',x:580,y:1100,scale:1.92});
  context.addSvg(context.assetText('blanket'));
  const m = id => may.querySelector('#'+id);
  const b = id => bong.querySelector('#'+id);
  const t = context.timeline();
  const move = (el,from,to,at) => t.fromTo(el,from,to,at);
  const blink = (el,at) => move(el,{scaleY:1},{scaleY:0.08,transformOrigin:'center center',duration:.12,repeat:1,yoyo:true,ease:'power1.inOut'},at);
  const rotate = (el,a,z,at,d=.5) => move(el,{rotation:a},{rotation:z,transformOrigin:'50% 15%',duration:d,ease:'sine.inOut'},at);
  t.set(bong,{x:572,y:1094}); rotate(b('head'),-7,12,.5,.45);
  rotate(b('right-ear'),0,12,.5,.35);
  move(bong,{x:572,y:1094},{x:505,y:1088,duration:1.2,ease:'power2.inOut'},1.9);
  move(bong,{x:505,y:1088},{x:455,y:1084,duration:1.25,ease:'sine.inOut'},3.15);
  rotate(b('left-arm'),0,-32,3.5,.5); rotate(b('right-arm'),0,25,4.45,.6);
  blink(b('eyes'),1.15); blink(b('eyes'),5.35);
  move(context.camera,{scale:1.018,x:-8,y:-10},{scale:1.035,x:-14,y:-20,duration:6,ease:'sine.inOut'},0);
  return {duration:6,seek(time){t.time(time,true);},reset(){t.pause(0);},dispose(){t.kill();}};
}
