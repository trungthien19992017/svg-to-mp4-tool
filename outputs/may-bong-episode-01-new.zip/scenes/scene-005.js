export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('bedroom'));
  context.addSvg(context.assetText('bed'));
  context.addSvg(context.assetText('lamp'));
  const may = context.character('may', {id:'may-actor',x:185,y:1030,scale:2.35});
  const bong = context.character('bong', {id:'bong-actor',x:580,y:1100,scale:1.92});
  context.addSvg(context.assetText('blanket'));
  const m = id => may.querySelector('#'+id);
  const b = id => bong.querySelector('#'+id);
  const t = context.timeline();
  const move = (el,from,to,at) => t.fromTo(el,from,to,at);
  const blink = (el,at) => move(el,{scaleY:1},{scaleY:0.08,transformOrigin:'center center',duration:.12,repeat:1,yoyo:true,ease:'power1.inOut'},at);
  const rotate = (el,a,z,at,d=.5) => move(el,{rotation:a},{rotation:z,transformOrigin:'50% 15%',duration:d,ease:'sine.inOut'},at);
  t.set(bong,{x:392,y:1081}); t.set(b('left-arm'),{rotation:-100,transformOrigin:'50% 15%'});
  t.set(b('right-arm'),{rotation:91,transformOrigin:'50% 15%'});
  t.set(b('head'),{rotation:-20,transformOrigin:'50% 15%'});
  t.set(b('eyes'),{scaleY:.10,transformOrigin:'center center'});
  t.set(m('head'),{rotation:5,transformOrigin:'50% 15%'});
  rotate(m('head'),5,13,.7,.7);
  // Free left arm gives one gentle pat; no IK or arbitrary contact solver.
  rotate(m('left-arm'),0,-34,1.6,.65);
  rotate(m('left-arm'),-34,-24,2.35,.42);
  rotate(b('head'),-20,-13,2.55,.45);
  rotate(m('left-arm'),-24,0,3.2,.75);
  move(m('eyes'),{scaleY:1},{scaleY:.1,transformOrigin:'center center',duration:.65,ease:'sine.inOut'},4.5);
  rotate(m('head'),13,6,4.7,.7);
  move(context.camera,{scale:1.095,x:-45,y:-53},{scale:1.01,x:-5,y:-5,duration:6,ease:'sine.inOut'},0);
  return {duration:6,seek(time){t.time(time,true);},reset(){t.pause(0);},dispose(){t.kill();}};
}
