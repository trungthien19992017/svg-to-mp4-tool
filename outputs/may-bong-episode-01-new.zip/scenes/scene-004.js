export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('bedroom'));
  context.addSvg(context.assetText('bed'));
  context.addSvg(context.assetText('lamp'));
  const may = context.character('may', {id:'may-actor',x:185,y:1030,scale:2.35});
  const bong = context.character('bong', {id:'bong-actor',x:580,y:1100,scale:1.92});
  context.addSvg(context.assetText('blanket'));
  const m = id => may.querySelector('#'+id);
  const b = id => bong.querySelector('#'+id);
  const t = context.timeline();
  const move = (el,from,to,at) => t.fromTo(el,from,to,at);
  const blink = (el,at) => move(el,{scaleY:1},{scaleY:0.08,transformOrigin:'center center',duration:.12,repeat:1,yoyo:true,ease:'power1.inOut'},at);
  const rotate = (el,a,z,at,d=.5) => move(el,{rotation:a},{rotation:z,transformOrigin:'50% 15%',duration:d,ease:'sine.inOut'},at);
  t.set(bong,{x:418,y:1081}); t.set(b('left-arm'),{rotation:-73,transformOrigin:'50% 15%'});
  t.set(b('right-arm'),{rotation:67,transformOrigin:'50% 15%'});
  t.set(b('eyes'),{scaleY:.10,transformOrigin:'center center'});
  t.set(b('head'),{rotation:-20,transformOrigin:'50% 15%'});
  t.set(m('head'),{rotation:20,transformOrigin:'50% 15%'});
  // Pull #1: arm and kitten move together, preserving the visual paw/arm overlap.
  rotate(m('right-arm'),0,-11,.6,.35);
  move(bong,{x:418},{x:410,duration:.35,ease:'power2.out'},.6);
  rotate(b('left-arm'),-73,-84,1.18,.24); rotate(b('right-arm'),67,78,1.18,.24);
  blink(m('eyes'),2.05);
  // Anticipation, larger second pull, kitten follows the same displacement.
  rotate(m('right-arm'),-11,3,2.8,.32);
  rotate(m('right-arm'),3,-24,3.2,.48);
  move(bong,{x:410},{x:392,duration:.48,ease:'power2.out'},3.2);
  rotate(b('left-arm'),-84,-100,3.78,.25); rotate(b('right-arm'),78,91,3.78,.25);
  rotate(b('tail'),0,16,3.8,.42);
  rotate(m('left-ear'),0,-15,4.5,.3); rotate(m('right-ear'),0,12,4.5,.3);
  rotate(m('right-arm'),-24,0,6,.8); rotate(m('head'),20,5,7.1,.65);
  move(context.camera,{scale:1.07,x:-32,y:-42},{scale:1.095,x:-45,y:-53,duration:8,ease:'sine.inOut'},0);
  return {duration:8,seek(time){t.time(time,true);},reset(){t.pause(0);},dispose(){t.kill();}};
}
