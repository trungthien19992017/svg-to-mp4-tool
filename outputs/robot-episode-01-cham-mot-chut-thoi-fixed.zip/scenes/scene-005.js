export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('room'));
  const female = context.character('female', {id:'female-actor',x:120,y:920,scale:1.35});
  const male = context.character('male', {id:'male-actor',x:350,y:920,scale:1.35});
  const F = id => female.querySelector('#'+id);
  const M = id => male.querySelector('#'+id);
  const t = context.timeline();
  const rot = (el,from,to,start,duration,ease='power2.inOut',origin='50% 50%') => t.fromTo(el,{rotation:from,transformOrigin:origin},{rotation:to,duration,ease,transformOrigin:origin},start);
  const move = (el,from,to,start,duration,ease='power2.inOut') => t.fromTo(el,from,{...to,duration,ease},start);
  const blink = (el,at) => t.fromTo(el,{scaleY:1,transformOrigin:'50% 50%'},{scaleY:.12,duration:.12,yoyo:true,repeat:1,transformOrigin:'50% 50%'},at);
  const expressionTracks=[];
  function expressions(actor, prefix, sequence) {
    const nodes=[...actor.querySelectorAll('.'+prefix+'-expr')];
    nodes.forEach(n=>{n.style.display='';n.style.opacity='0';});
    expressionTracks.push({nodes,sequence});
  }
  function applyExpressions(time) {
    for(const {nodes,sequence} of expressionTracks){
      let active=sequence[0][1], previous=null, transition=-1;
      for(let i=1;i<sequence.length;i++) if(time>=sequence[i][0]) {
        previous=sequence[i-1][1];active=sequence[i][1];transition=sequence[i][0];
      }
      const fade=transition>=0?Math.min(1,(time-transition)/.12):1;
      nodes.forEach(n=>{
        n.style.opacity=String(n.dataset.e===active?fade:(n.dataset.e===previous?1-fade:0));
      });
    }
  }

  // Continuity from scene 004 at local time 7.000.
  t.set(F('f-head'), {rotation:-3,transformOrigin:'50% 75%'}, 0);
  t.set(F('f-root'), {x:-9,y:8}, 0);
  t.set(F('f-arm-right'), {x:30,y:-2,rotation:-8,transformOrigin:'50% 0%'}, 0);
  t.set(M('m-head'), {rotation:-6,transformOrigin:'50% 75%'}, 0);
  t.set(M('m-arm-left'), {x:-30,y:-2,rotation:8,transformOrigin:'50% 0%'}, 0);
  t.set(context.camera, {scale:1.075,x:-35,y:-18}, 0);
  expressions(female,'f',[[0,'satisfied'],[1.8,'happy'],[4.5,'satisfied']]);
  expressions(male,'m',[[0,'satisfied'],[1.5,'happy'],[4.4,'satisfied']]);
  // Keep both hand transforms fixed from scene 004 (including shoulder rotations).

  rot(F('f-head'),-3,-11,1.1,1.1,'sine.inOut','50% 75%');
  rot(M('m-head'),-6,7,1.0,1.1,'sine.inOut','50% 75%');
  const heart=context.addSvg(context.assetText('heart'),{id:'love-heart',x:490,y:920,scale:1});
  move(heart,{opacity:0,y:920,scale:.4},{opacity:1,y:820,scale:1.1},2.3,1.1,'power2.out');
  move(heart,{opacity:1,y:820},{opacity:0,y:745},3.6,1.2,'power1.in');
  move(context.camera,{scale:1.075,x:-35,y:-18},{scale:.93,x:25,y:32},2.0,3.7,'sine.inOut');
  const ending=context.addSvg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1920"><text x="540" y="1550" font-size="37" text-anchor="middle" fill="#fff7e9" font-family="Arial, sans-serif">Đôi khi, hạnh phúc chỉ cách nhau</text><text x="540" y="1610" font-size="42" text-anchor="middle" fill="#fff7e9" font-family="Arial, sans-serif">một cái chạm. ❤️</text></svg>');
  move(ending,{opacity:0},{opacity:1},4.0,1.0,'sine.out');
  return {duration:6,seek(time){t.time(time,true);applyExpressions(time);},reset(){t.pause(0);},dispose(){t.kill();}};
}
