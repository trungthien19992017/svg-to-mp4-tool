export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('room'));
  const female = context.character('female', {id:'female-actor',x:120,y:920,scale:1.35});
  const male = context.character('male', {id:'male-actor',x:350,y:920,scale:1.35});
  const F = id => female.querySelector('#'+id);
  const M = id => male.querySelector('#'+id);
  const t = context.timeline();
  const rot = (el,from,to,start,duration,ease='power2.inOut',origin='50% 50%') => t.fromTo(el,{rotation:from,transformOrigin:origin},{rotation:to,duration,ease,transformOrigin:origin},start);
  const move = (el,from,to,start,duration,ease='power2.inOut') => t.fromTo(el,from,{...to,duration,ease},start);
  const blink = (el,at) => t.fromTo(el,{scaleY:1,transformOrigin:'50% 50%'},{scaleY:.12,duration:.12,yoyo:true,repeat:1,transformOrigin:'50% 50%'},at);
  const expressionTracks=[];
  function expressions(actor, prefix, sequence) {
    const nodes=[...actor.querySelectorAll('.'+prefix+'-expr')];
    nodes.forEach(n=>{n.style.display='';n.style.opacity='0';});
    expressionTracks.push({nodes,sequence});
  }
  function applyExpressions(time) {
    for(const {nodes,sequence} of expressionTracks){
      let active=sequence[0][1], previous=null, transition=-1;
      for(let i=1;i<sequence.length;i++) if(time>=sequence[i][0]) {
        previous=sequence[i-1][1];active=sequence[i][1];transition=sequence[i][0];
      }
      const fade=transition>=0?Math.min(1,(time-transition)/.12):1;
      nodes.forEach(n=>{
        n.style.opacity=String(n.dataset.e===active?fade:(n.dataset.e===previous?1-fade:0));
      });
    }
  }

  // Continuity from scene 002 at local time 6.000.
  t.set(F('f-head'), {rotation:12,transformOrigin:'50% 75%'}, 0);
  t.set(F('f-root'), {x:-9,y:0}, 0);
  t.set(F('f-arm-right'), {x:-8,y:5,rotation:-13,transformOrigin:'50% 0%'}, 0);
  t.set(M('m-head'), {rotation:-11,transformOrigin:'50% 75%'}, 0);
  t.set(context.camera, {scale:1.045,x:-23,y:-18}, 0);
  expressions(female,'f',[[0,'sad'],[4.4,'content']]);
  expressions(male,'m',[[0,'default'],[3.1,'happy']]);
  rot(F('f-head'),12,13,.45,.9,'sine.inOut','50% 75%');
  move(F('f-root'),{x:-9,y:0},{x:-9,y:8},1,.8,'sine.out');
  rot(M('m-head'),-11,-13,2.0,.7,'power2.inOut','50% 75%');
  // Withdraw the startled arm only after the scene begins; keep the cut identical.
  move(F('f-arm-right'),{x:-8,y:5,rotation:-13},{x:0,y:0,rotation:0},.55,.9,'sine.inOut');
  blink(M('m-eyes'),2.8);
  rot(M('m-head'),-13,-5,3.6,.9,'sine.inOut','50% 75%');
  rot(F('f-head'),13,2,4.3,.75,'sine.inOut','50% 75%');
  move(context.camera,{scale:1.045,x:-23,y:-18},{scale:1.05,x:-25,y:-18},.4,5.5,'sine.inOut');
  return {duration:6,seek(time){t.time(time,true);applyExpressions(time);},reset(){t.pause(0);},dispose(){t.kill();}};
}
