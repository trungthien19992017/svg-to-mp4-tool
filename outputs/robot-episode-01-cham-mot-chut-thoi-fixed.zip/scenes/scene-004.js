export function createScene(context) {
  const {gsap} = context;
  context.addSvg(context.assetText('room'));
  const female = context.character('female', {id:'female-actor',x:120,y:920,scale:1.35});
  const male = context.character('male', {id:'male-actor',x:350,y:920,scale:1.35});
  const F = id => female.querySelector('#'+id);
  const M = id => male.querySelector('#'+id);
  const t = context.timeline();
  const rot = (el,from,to,start,duration,ease='power2.inOut',origin='50% 50%') => t.fromTo(el,{rotation:from,transformOrigin:origin},{rotation:to,duration,ease,transformOrigin:origin},start);
  const move = (el,from,to,start,duration,ease='power2.inOut') => t.fromTo(el,from,{...to,duration,ease},start);
  const blink = (el,at) => t.fromTo(el,{scaleY:1,transformOrigin:'50% 50%'},{scaleY:.12,duration:.12,yoyo:true,repeat:1,transformOrigin:'50% 50%'},at);
  const expressionTracks=[];
  function expressions(actor, prefix, sequence) {
    const nodes=[...actor.querySelectorAll('.'+prefix+'-expr')];
    nodes.forEach(n=>{n.style.display='';n.style.opacity='0';});
    expressionTracks.push({nodes,sequence});
  }
  function applyExpressions(time) {
    for(const {nodes,sequence} of expressionTracks){
      let active=sequence[0][1], previous=null, transition=-1;
      for(let i=1;i<sequence.length;i++) if(time>=sequence[i][0]) {
        previous=sequence[i-1][1];active=sequence[i][1];transition=sequence[i][0];
      }
      const fade=transition>=0?Math.min(1,(time-transition)/.12):1;
      nodes.forEach(n=>{
        n.style.opacity=String(n.dataset.e===active?fade:(n.dataset.e===previous?1-fade:0));
      });
    }
  }

  // Continuity from scene 003 at local time 6.000.
  t.set(F('f-head'), {rotation:2,transformOrigin:'50% 75%'}, 0);
  t.set(F('f-root'), {x:-9,y:8}, 0);
  t.set(M('m-head'), {rotation:-5,transformOrigin:'50% 75%'}, 0);
  t.set(context.camera, {scale:1.05,x:-25,y:-18}, 0);
  expressions(female,'f',[[0,'content'],[2.0,'surprised'],[4.5,'satisfied']]);
  expressions(male,'m',[[0,'happy'],[4.3,'satisfied']]);
  rot(M('m-head'),-5,-6,.5,.5,'sine.inOut','50% 75%');
  rot(M('m-arm-left'),0,8,.8,.35,'power1.out','50% 0%');
  move(M('m-arm-left'),{x:0,y:0},{x:-30,y:-2},1.3,1.0,'power2.out');
  rot(F('f-head'),2,-9,2.0,.35,'power2.out','50% 75%');
  rot(F('f-arm-right'),0,-8,2.7,.45,'power2.out','50% 0%');
  move(F('f-arm-right'),{x:0,y:0},{x:30,y:-2},3.0,1.1,'power2.inOut');
  /* Both hands stay at the same endpoint after 4.1s; no post-contact hand tween. */
  rot(F('f-head'),-9,-3,4.7,.7,'sine.inOut','50% 75%');
  move(context.camera,{scale:1.05,x:-25,y:-18},{scale:1.075,x:-35,y:-18},1.2,5,'sine.inOut');
  return {duration:7,seek(time){t.time(time,true);applyExpressions(time);},reset(){t.pause(0);},dispose(){t.kill();}};
}
