/* Episode 02: reused approved V4 rig; all authored actions are catalogued Partial. */
const {RIG_DATA} = (() => {
const RIG_DATA = {"male":{"sourceRevision":"pair-calibrated-v2","nodes":{"root":{"parent":null,"mount":[0,0],"limits":[-180,180],"anchors":{"torso":[232,485]}},"torso":{"parent":"root","mount":[232,485],"limits":[-180,180],"anchors":{"neck":[0,-103],"shoulder-L":[-80,-72],"hip-L":[-69,83],"shoulder-R":[80,-72],"hip-R":[69,83]}},"neck":{"parent":"torso","mount":[0,-103],"limits":[-180,180],"anchors":{"head":[0,0]}},"head":{"parent":"neck","mount":[0,0],"limits":[-15,15],"anchors":{"top":[-1.0,-363.5],"face":[0,-175],"side-L":[-204.5,-174.5],"side-R":[202.5,-174.5]}},"upper-arm-L":{"parent":"torso","mount":[-80,-72],"limits":[-70,70],"anchors":{"elbow":[-27.04,75.4]}},"forearm-L":{"parent":"upper-arm-L","mount":[-27.04,75.4],"limits":[-65,65],"anchors":{"wrist":[-24.96,69.6]}},"hand-L":{"parent":"forearm-L","mount":[-24.96,69.6],"limits":[-30,30],"anchors":{"contact":[0,35]}},"thigh-L":{"parent":"torso","mount":[-69,83],"limits":[-40,40],"anchors":{"knee":[0,48]}},"shin-L":{"parent":"thigh-L","mount":[0,48],"limits":[-65,65],"anchors":{"ankle":[0,50]}},"foot-L":{"parent":"shin-L","mount":[0,50],"limits":[-20,20],"anchors":{"sole":[0,50.5],"toe":[62.5,30]}},"upper-arm-R":{"parent":"torso","mount":[80,-72],"limits":[-70,70],"anchors":{"elbow":[27.04,75.4]}},"forearm-R":{"parent":"upper-arm-R","mount":[27.04,75.4],"limits":[-65,65],"anchors":{"wrist":[24.96,69.6]}},"hand-R":{"parent":"forearm-R","mount":[24.96,69.6],"limits":[-30,30],"anchors":{"contact":[0,35]}},"thigh-R":{"parent":"torso","mount":[69,83],"limits":[-40,40],"anchors":{"knee":[0,48]}},"shin-R":{"parent":"thigh-R","mount":[0,48],"limits":[-65,65],"anchors":{"ankle":[0,50]}},"foot-R":{"parent":"shin-R","mount":[0,50],"limits":[-20,20],"anchors":{"sole":[0,50.5],"toe":[62.5,30]}}},"soleY":716.5},"female":{"sourceRevision":"pair-calibrated-v2","nodes":{"root":{"parent":null,"mount":[0,0],"limits":[-180,180],"anchors":{"torso":[223,521]}},"torso":{"parent":"root","mount":[223,521],"limits":[-180,180],"anchors":{"neck":[0,-82],"shoulder-L":[-75,-56],"hip-L":[-44,73],"shoulder-R":[75,-56],"hip-R":[44,73]}},"neck":{"parent":"torso","mount":[0,-82],"limits":[-180,180],"anchors":{"head":[0,0]}},"head":{"parent":"neck","mount":[0,0],"limits":[-15,15],"anchors":{"top":[-2.0,-420.5],"face":[0,-175],"side-L":[-192.5,-163.5],"side-R":[188.5,-163.5]}},"upper-arm-L":{"parent":"torso","mount":[-75,-56],"limits":[-70,70],"anchors":{"elbow":[-21.32,54.6]}},"forearm-L":{"parent":"upper-arm-L","mount":[-21.32,54.6],"limits":[-65,65],"anchors":{"wrist":[-19.68,50.4]}},"hand-L":{"parent":"forearm-L","mount":[-19.68,50.4],"limits":[-30,30],"anchors":{"contact":[0,32.5]}},"thigh-L":{"parent":"torso","mount":[-44,73],"limits":[-40,40],"anchors":{"knee":[0,48]}},"shin-L":{"parent":"thigh-L","mount":[0,48],"limits":[-65,65],"anchors":{"ankle":[0,40]}},"foot-L":{"parent":"shin-L","mount":[0,40],"limits":[-20,20],"anchors":{"sole":[0,28.5],"toe":[27.5,0]}},"upper-arm-R":{"parent":"torso","mount":[75,-56],"limits":[-70,70],"anchors":{"elbow":[21.32,54.6]}},"forearm-R":{"parent":"upper-arm-R","mount":[21.32,54.6],"limits":[-65,65],"anchors":{"wrist":[19.68,50.4]}},"hand-R":{"parent":"forearm-R","mount":[19.68,50.4],"limits":[-30,30],"anchors":{"contact":[0,32.5]}},"thigh-R":{"parent":"torso","mount":[44,73],"limits":[-40,40],"anchors":{"knee":[0,48]}},"shin-R":{"parent":"thigh-R","mount":[0,48],"limits":[-65,65],"anchors":{"ankle":[0,40]}},"foot-R":{"parent":"shin-R","mount":[0,40],"limits":[-20,20],"anchors":{"sole":[0,28.5],"toe":[27.5,0]}}},"soleY":710.5},"contactSolution":{"male":{"upper-arm-R":-9.647185987650886,"forearm-R":-65,"hand-R":-15.352814012349114},"female":{"upper-arm-L":40.70562802469823,"forearm-L":39,"hand-L":10.294371975301772},"scaleMale":0.7,"scaleFemale":0.7336232905681658,"maleX":225,"femaleX":539.2187426275393,"floorY":740,"toleranceStagePx":2}};
return {RIG_DATA};
})();

const {namespaceSvg} = (() => {
/** Fragment-only SVG ID namespacing. No engine or Studio global mutations. */
const reserved = new Set();
function namespaceSvg(markup, requested) {
    const safe = String(requested).replace(/[^a-zA-Z0-9_-]/g, '-');
    let prefix = safe;
    for (let index = 2; reserved.has(prefix); index++) prefix = safe + '-' + index;
    reserved.add(prefix);
    const parsed = new DOMParser().parseFromString(markup, 'image/svg+xml');
    if (parsed.querySelector('parsererror') || parsed.documentElement.localName !== 'svg') {
        reserved.delete(prefix);
        throw new Error('Invalid SVG asset: ' + requested);
    }
    const idMap = new Map();
    for (const element of parsed.querySelectorAll('[id]')) {
        const original = element.getAttribute('id');
        if (idMap.has(original)) throw new Error('Duplicate source SVG ID ' + original);
        idMap.set(original, prefix + '--' + original);
    }
    for (const element of parsed.querySelectorAll('*')) {
        for (const attribute of [...element.attributes]) {
            let value = attribute.value;
            if (attribute.name === 'id') value = idMap.get(value);
            else {
                value = value.replace(/url\(\s*['"]?#([^\s)'";]+)['"]?\s*\)/g,
                    (all, id) => idMap.has(id) ? 'url(#' + idMap.get(id) + ')' : all);
                if ((attribute.localName === 'href') && value.startsWith('#')) {
                    value = '#' + (idMap.get(value.slice(1)) || value.slice(1));
                }
            }
            if (value !== attribute.value) element.setAttribute(attribute.name, value);
        }
    }
    return {
        markup: new XMLSerializer().serializeToString(parsed.documentElement),
        prefix,
        release() { reserved.delete(prefix); }
    };
}
return {namespaceSvg};
})();

const {createActor} = (() => {
const PARTS = ['root', 'torso', 'neck', 'head', 'upper-arm-L', 'forearm-L', 'hand-L',
    'upper-arm-R', 'forearm-R', 'hand-R', 'thigh-L', 'shin-L', 'foot-L',
    'thigh-R', 'shin-R', 'foot-R'];
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/** Original V4 vector nodes are never redrawn. Only authored group transforms change. */
function createActor(group, sex, layout) {
    const rig = RIG_DATA[sex];
    if (!rig) throw new Error('Missing source rig: ' + sex);
    const views = [...group.children].filter(node => node.hasAttribute('data-view'));
    const front = views.find(node => node.getAttribute('data-view') === 'front');
    if (!front) throw new Error(sex + ': front view is required for verified source anchors');
    const nodes = {};
    for (const name of PARTS) {
        const found = front.querySelector('[data-part="' + name + '"]');
        if (!found) throw new Error(sex + ': missing rig node ' + name);
        nodes[name] = found;
    }
    const expressions = [...front.querySelectorAll('[data-expression]')];
    const expressionIds = new Set(expressions.map(node => node.getAttribute('data-expression')));
    if (expressionIds.size !== 12) throw new Error(sex + ': expected exactly 12 front expressions');
    const eyeNodes = [];
    for (const expr of expressions) {
        for (const eye of expr.querySelectorAll('[data-blink-pivot]')) {
            const pivot = eye.getAttribute('data-blink-pivot').trim().split(/\s+/).map(Number);
            if (pivot.length !== 2 || !pivot.every(Number.isFinite)) throw new Error('Bad blink pivot');
            eyeNodes.push({eye, pivot, closed: expr.getAttribute('data-closed-eyes') === 'true'});
        }
    }
    const pose = {x: layout.x, y: layout.y, scale: layout.scale};
    function render(state) {
        for (const view of views) { view.removeAttribute('visibility'); view.style.display = view === front ? '' : 'none'; }
        const selected = expressionIds.has(state.expression) ? state.expression : 'default';
        for (const expr of expressions) { expr.removeAttribute('visibility'); expr.style.display = expr.getAttribute('data-expression') === selected ? '' : 'none'; }
        const closure = clamp(state.blink || 0, 0, 1);
        for (const item of eyeNodes) {
            const [x, y] = item.pivot;
            const sy = item.closed ? 1 : 1 - closure * 0.96;
            item.eye.setAttribute('transform', 'translate(' + x + ' ' + y + ') scale(1 ' + sy + ') translate(' + -x + ' ' + -y + ')');
        }
        const gait = clamp(state.gait || 0, 0, 1);
        const phase = (state.gaitTime || 0) * Math.PI * 2 * 1.6;
        const swing = Math.sin(phase) * gait;
        const liftL = Math.max(0, Math.sin(phase)) * gait;
        const liftR = Math.max(0, -Math.sin(phase)) * gait;
        const rotations = {
            'head': state.headRotation || 0,
            'upper-arm-L': (state.armL?.upper || 0) + swing * 9,
            'forearm-L': state.armL?.forearm || 0,
            'hand-L': state.armL?.hand || 0,
            'upper-arm-R': (state.armR?.upper || 0) - swing * 9,
            'forearm-R': state.armR?.forearm || 0,
            'hand-R': state.armR?.hand || 0,
            'thigh-L': swing * 16,
            'shin-L': -liftL * 18,
            'foot-L': -swing * 6,
            'thigh-R': -swing * 16,
            'shin-R': -liftR * 18,
            'foot-R': swing * 6
        };
        for (const name of PARTS) {
            const data = rig.nodes[name];
            const [mx, my] = data.mount;
            const angle = rotations[name] || 0;
            if (angle < data.limits[0] - 0.0001 || angle > data.limits[1] + 0.0001) {
                throw new Error(sex + ' joint limit: ' + name + ' = ' + angle);
            }
            const dy = name === 'torso' ? (state.bodyY || 0) :
                name === 'neck' ? (state.neckY || 0) :
                name === 'head' ? (state.headY || 0) : 0;
            nodes[name].setAttribute('transform', 'translate(' + mx + ' ' + (my + dy) + ') rotate(' + angle + ')');
        }
        group.setAttribute('transform', 'translate(' + state.x + ' ' + pose.y + ') scale(' + pose.scale + ')');
    }
    function anchorWorld(partName, anchorName) {
        const anchor = rig.nodes[partName]?.anchors[anchorName];
        const part = nodes[partName];
        if (!anchor || !part) throw new Error('Missing contact anchor ' + sex + ':' + partName + '.' + anchorName);
        const matrix = part.getCTM();
        if (!matrix) throw new Error('Unattached actor');
        const point = new DOMPoint(anchor[0], anchor[1]).matrixTransform(matrix);
        return {x: point.x, y: point.y};
    }
    return {sex, group, rig, layout: pose, render, anchorWorld, expressions: [...expressionIds],
        dispose() { group.remove(); }};
}
return {createActor};
})();

const {actionChannels, createMotionComposer, createTimelineMotion} = (() => {
/**
 * Phase 03 / reusable deterministic GSAP timeline-driven motion.
 * Studio API usage: context.timeline(), context.gsap; no autonomous tweens or callbacks.
 * Source V4 status: motions are TECHNICAL PROTOTYPES, not approved animation art.
 */
const EPS = 1e-8;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const lerp = (a, b, t) => a + (b - a) * t;
const CHANNELS = Object.freeze({
    idle: ['head-y'],
    blink: ['blink'],
    breathe: ['neck-y'],
    lookAt: ['head-rotation'],
    headTilt: ['head-rotation'],
    happyReaction: ['expression', 'head-y'],
    surprisedReaction: ['expression', 'head-y'],
    sadReaction: ['expression', 'head-rotation'],
    reach: ['arm-near'],
    touch: ['arm-near'],
    release: ['arm-near'],
    walk: ['actor-x', 'gait', 'arm-near'],
    stopWalking: ['gait', 'arm-near']
});
const EASINGS = Object.freeze({
    none: t => t,
    'sine.inOut': t => -(Math.cos(Math.PI * t) - 1) / 2,
    'sine.out': t => Math.sin(Math.PI * t / 2),
    'power1.inOut': t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2,
    'power2.out': t => 1 - Math.pow(1 - t, 3),
    'power2.inOut': t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
});
const ALLOWED_EXPRESSIONS = new Set([
    'shy', 'loving', 'worried', 'crying', 'sleepy', 'touched',
    'default', 'cheerful', 'sad', 'surprised', 'content', 'pleased'
]);

function actionChannels(type) {
    if (!CHANNELS[type]) throw new Error('Unknown motion action: ' + type);
    return [...CHANNELS[type]];
}
function createMotionComposer({duration, actors, gsap = null}) {
    if (!Number.isFinite(duration) || duration <= 0) throw new Error('Finite duration required');
    const ids = Object.keys(actors);
    if (!ids.length) throw new Error('At least one actor required');
    const schedule = [];
    let serial = 0;
    let finalized = false;

    function add(type, actor, start, actionDuration, options = {}) {
        if (finalized) throw new Error('Motion schedule already finalized');
        actionChannels(type);
        if (!actors[actor]) throw new Error('Unknown actor ' + actor);
        if (![start, actionDuration].every(Number.isFinite) || start < 0 || actionDuration <= 0 || start + actionDuration > duration + EPS) {
            throw new Error('Invalid action interval ' + type);
        }
        if (['happyReaction', 'surprisedReaction', 'sadReaction'].includes(type)) {
            const target = options.expression || ({happyReaction:'pleased', surprisedReaction:'surprised', sadReaction:'sad'})[type];
            if (!ALLOWED_EXPRESSIONS.has(target)) throw new Error('Unknown authored expression ' + target);
        }
        if (['reach', 'touch', 'release'].includes(type)) {
            if (!['L', 'R'].includes(options.arm) || !options.targetAngles) throw new Error('Authored arm/targetAngles required');
            for (const key of ['upper','forearm','hand']) {
                if (!Number.isFinite(options.targetAngles[key])) throw new Error('Non-finite joint target ' + key);
            }
        }
        const channels = actionChannels(type);
        const end = start + actionDuration;
        for (const previous of schedule) {
            if (previous.actor !== actor || !channels.some(channel => previous.channels.includes(channel))) continue;
            if (start < previous.end - EPS && previous.start < end - EPS) {
                throw new Error('Conflicting motion channels: ' + actor + ' ' + type + ' / ' + previous.type +
                    ' (' + channels.filter(channel => previous.channels.includes(channel)).join(',') + ')');
            }
        }
        const action = Object.freeze({id: options.id || type + '-' + (++serial),
            type, actor, start, end, duration: actionDuration,
            easing: options.easing || 'sine.inOut', channels, options: {...options}});
        if (!EASINGS[action.easing] && !(gsap && typeof gsap.parseEase === 'function')) {
            throw new Error('Unsupported easing: ' + action.easing);
        }
        schedule.push(action);
        return action;
    }
    function finalize() {
        schedule.sort((a,b) => a.start - b.start || a.end - b.end || a.id.localeCompare(b.id));
        finalized = true;
        return schedule.slice();
    }
    function ease(action, p) {
        const fn = gsap && typeof gsap.parseEase === 'function' ? gsap.parseEase(action.easing) : EASINGS[action.easing];
        if (typeof fn !== 'function') throw new Error('Unknown easing ' + action.easing);
        return fn(clamp(p, 0, 1));
    }
    function evaluate(t) {
        if (!finalized) finalize();
        const time = clamp(Number.isFinite(t) ? t : 0, 0, duration);
        const result = {};
        for (const [id, actor] of Object.entries(actors)) {
            result[id] = {
                x: actor.x, y: actor.y, scale: actor.scale,
                headY: 0, headRotation: 0, neckY: 0, bodyY: 0,
                expression: 'default', blink: 0, gait: 0, gaitTime: time,
                armL: {upper:0,forearm:0,hand:0}, armR: {upper:0,forearm:0,hand:0}
            };
        }
        for (const action of schedule) {
            if (time + EPS < action.start) continue;
            const state = result[action.actor];
            const o = action.options;
            const p = clamp((time - action.start) / action.duration, 0, 1);
            const q = ease(action, p);
            const within = time <= action.end + EPS;
            switch (action.type) {
                case 'idle': {
                    // Neutral head bob, finite and returns to rest at action end.
                    state.headY = within ? Math.sin(2 * Math.PI * p * (o.cycles || 1)) * (o.amplitude ?? 1.5) * Math.sin(Math.PI * p) : 0;
                    break;
                }
                case 'breathe': {
                    state.neckY = within ? Math.sin(2 * Math.PI * (time - action.start) / (o.period || 2.8)) * (o.amplitude ?? 1.4) * Math.sin(Math.PI * p) : 0;
                    break;
                }
                case 'blink': {
                    state.blink = within ? Math.sin(Math.PI * p) : 0;
                    break;
                }
                case 'lookAt':
                case 'headTilt': {
                    state.headRotation = lerp(o['fr'+'om'] ?? 0, o.to ?? 0, q);
                    break;
                }
                case 'happyReaction':
                case 'surprisedReaction': {
                    state.expression = o.expression || (action.type === 'happyReaction' ? 'pleased' : 'surprised');
                    state.headY = lerp(o.fromY ?? 0, o.toY ?? (action.type === 'happyReaction' ? -2 : -5), q);
                    break;
                }
                case 'sadReaction': {
                    state.expression = o.expression || 'sad';
                    state.headRotation = lerp(o['fr'+'om'] ?? 0, o.to ?? 6, q);
                    break;
                }
                case 'reach':
                case 'touch':
                case 'release': {
                    const origin = o.fromFactor ?? (action.type === 'reach' ? 0 : action.type === 'release' ? 1 : .92);
                    const to = o.toFactor ?? (action.type === 'reach' ? .92 : action.type === 'release' ? 0 : 1);
                    const factor = lerp(origin, to, q);
                    const key = o.arm === 'L' ? 'armL' : 'armR';
                    state[key] = {
                        upper: o.targetAngles.upper * factor,
                        forearm: o.targetAngles.forearm * factor,
                        hand: o.targetAngles.hand * factor
                    };
                    break;
                }
                case 'walk': {
                    state.x = lerp(o.fromX ?? actors[action.actor].x, o.toX ?? actors[action.actor].x, q);
                    const fadeIn = clamp(p / (o.ramp || .16), 0, 1);
                    state.gait = within ? fadeIn : 1;
                    break;
                }
                case 'stopWalking': {
                    state.gait = lerp(o.fromGait ?? 1, 0, q);
                    break;
                }
                default: throw new Error('Missing action implementation ' + action.type);
            }
        }
        for (const state of Object.values(result)) {
            state.bodyY = -3.5 * Math.abs(Math.sin(time * Math.PI * 2 * 1.6)) * state.gait;
        }
        return result;
    }
    return {add, finalize, evaluate, get actions() {return schedule.slice();}, duration};
}

/** One GSAP-controlled absolute clock; all SVG state is a pure function of that clock. */
function createTimelineMotion(context, composer, renderFrame) {
    const duration = composer.duration;
    const clock = {time:0};
    const timeline = context.timeline();
    timeline.to(clock, {time:duration, duration, ease:'none', immediateRender:false}, 0);
    let disposed = false;
    function seek(time) {
        if (disposed) return;
        const t = clamp(Number.isFinite(time) ? time : 0, 0, duration);
        timeline.time(t, true); // callback suppression safe: no visual callbacks exist.
        renderFrame(composer.evaluate(clock.time), clock.time);
    }
    // Studio owns initial seek; avoid camera mutation during construction.
    return {
        duration, timeline, seek,
        reset() {if (!disposed) {timeline.pause(0); clock.time = 0; seek(0);}},
        dispose() {if (!disposed) {disposed = true; timeline.kill();}}
    };
}
return {actionChannels, createMotionComposer, createTimelineMotion};
})();

const {createDeterministicRain} = (() => {
/** Exact V3 rain geometry, SMIL timings converted to absolute scene time. */
function createDeterministicRain(svgGroup) {
    const drops = [];
    for (const node of svgGroup.querySelectorAll('[data-rain-duration]')) {
        const origin = node.getAttribute('data-rain-' + 'fr' + 'om').split(',').map(Number);
        const to = node.getAttribute('data-rain-to').split(',').map(Number);
        const duration = Number(node.getAttribute('data-rain-duration'));
        const begin = Number(node.getAttribute('data-rain-begin'));
        if (!origin.every(Number.isFinite) || !to.every(Number.isFinite) ||
            !Number.isFinite(duration) || duration <= 0 || !Number.isFinite(begin)) {
            throw new Error('Invalid V3 rain metadata');
        }
        drops.push({node, origin, to, duration, begin});
    }
    function seek(time) {
        for (const drop of drops) {
            const phase = (((time - drop.begin) % drop.duration) + drop.duration) % drop.duration / drop.duration;
            const x = drop.origin[0] + (drop.to[0] - drop.origin[0]) * phase;
            const y = drop.origin[1] + (drop.to[1] - drop.origin[1]) * phase;
            drop.node.setAttribute('transform', 'translate(' + x.toFixed(4) + ' ' + y.toFixed(4) + ')');
        }
    }
    return {seek, count: drops.length};
}
return {createDeterministicRain};
})();

const {createEpisodeScene} = (() => {
const ENV_BACK = ['background-far', 'rain-back', 'walls', 'rain-glass', 'window-reflections', 'floor', 'furniture'];
const ENV_FRONT = ['foreground','lighting'];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const easeInOut = t => 0.5-0.5*Math.cos(Math.PI*t);

function cameraAt(scene, localTime) {
    const frames = scene.cameraKeyframes;
    if (localTime <= frames[0].localTime) return frames[0];
    for (let i=0;i<frames.length-1;i++) {
        const a=frames[i], b=frames[i+1];
        if (localTime <= b.localTime) {
            const k=clamp((localTime-a.localTime)/(b.localTime-a.localTime),0,1);
            const u=a.easeToNext === 'hold' ? 0 : easeInOut(k);
            return {x:a.x+(b.x-a.x)*u,y:a.y+(b.y-a.y)*u,
                scale:a.scale+(b.scale-a.scale)*u,rotation:a.rotation+(b.rotation-a.rotation)*u};
        }
    }
    return frames[frames.length-1];
}

function createEpisodeScene(context, sceneId) {
    if (!context.canvas || !context.assetText || !context.addSvg || !context.timeline || !context.gsap || !context.camera) {
        throw new Error('Story Format v1 scene context required');
    }
    // Story contract v1: project-local data is loaded via a declared JSON asset.
    const EPISODE = JSON.parse(context.assetText('episode-data'));
    const scene = EPISODE.scenes.find(x=>x.id===sceneId);
    if (!scene || Math.abs(context.duration-scene.duration)>1e-7) throw new Error('Scene duration mismatch: '+sceneId);
    const mounted = [], namespaces = [], rainControllers = [];
    let timelineMotion=null, disposed=false;
    try {
        // Studio-managed mount. Every scene owns a single isolated root.
        const sceneRoot = context.addSvg('<svg xmlns="http://www.w3.org/2000/svg"><g/></svg>');
        sceneRoot.setAttribute('data-episode-root', context.sceneId);
        mounted.push(sceneRoot);
        function add(id, parent) {
            const source = namespaceSvg(context.assetText(id), context.sceneId + '-' + id);
            namespaces.push(source);
            const group = context.addSvg(source.markup, {parent: parent || sceneRoot});
            group.setAttribute('data-episode-asset', id);
            group.setAttribute('data-episode-scene', context.sceneId);
            mounted.push(group);
            return group;
        }
        for (const name of ENV_BACK) {
            const group=add(name);
            if (name==='rain-back' || name==='rain-glass') rainControllers.push(createDeterministicRain(group));
        }
        const stage=document.createElementNS('http://www.w3.org/2000/svg','g');
        stage.setAttribute('data-stage','robot-pair');
        stage.setAttribute('transform',EPISODE.stage.stageTransform);
        sceneRoot.appendChild(stage);
        mounted.push(stage);
        const male=createActor(add('male-art',stage),'male',{
            x:EPISODE.stage.maleX,y:EPISODE.stage.maleY,scale:EPISODE.stage.scaleMale});
        const female=createActor(add('female-art',stage),'female',{
            x:EPISODE.stage.femaleX,y:EPISODE.stage.femaleY,scale:EPISODE.stage.scaleFemale});
        const invoice = add('invoice-prop');
        invoice.setAttribute('data-prop-approved', 'invoice-prop.svg');
        for (const name of ENV_FRONT) add(name);
        const composer=createMotionComposer({duration:scene.duration,gsap:context.gsap,actors:{
            male:{x:EPISODE.stage.maleX,y:EPISODE.stage.maleY,scale:EPISODE.stage.scaleMale},
            female:{x:EPISODE.stage.femaleX,y:EPISODE.stage.femaleY,scale:EPISODE.stage.scaleFemale}
        }});
        for (const cue of scene.actions) {
            composer.add(cue.action,cue.actor,cue.localStart,cue.duration,
                {...cue.options,easing:cue.easing,id:cue.id});
        }
        composer.finalize();
        timelineMotion=createTimelineMotion(context,composer,(state,time)=>{
            // Phase 07R: align visible hand silhouettes, not the old downward-facing rig anchors.
            // Female left-hand circle r=22; male right-hand circle r=31 + stroke 4.
            // Calibrated stage-space correction 7.703044551 units, smoothly applied
            // only while contact is established (or being released).
            const contactCorrection = clamp((time - 3.4) / 0.6, 0, 1);
            state.female.x -= 7.703044551 * contactCorrection;
            male.render(state.male);
            female.render(state.female);
            // Approved prop, positioned in screen coordinates. No new character gesture is fabricated.
            const visible = time >= 0;
            invoice.style.display = visible ? '' : 'none';
            const propScale = 0.62;
            const propX = 610, propY = 885;
            invoice.setAttribute('transform', 'translate(' + propX + ' ' + propY + ') scale(' + propScale + ')');
            // Rain phase is global, not restarted at scene boundaries.
            for (const rain of rainControllers) rain.seek(scene.globalStart+time);
            // Camera is applied only from the explicit scene seek, never during setup.
            // Contact alignment is pre-calibrated in the exact V4 rig joint angles.
            // Runtime DOM getCTM() is intentionally NOT used here: Studio initializes
            // scenes while hidden, where browser CTM readings can be inconsistent.
            // The visible-scene geometry is measured in the separate QA harness.
        });
        return {
            duration:scene.duration,
            seek(time) {
                if (disposed) return;
                timelineMotion.seek(time);
                const camera = cameraAt(scene, Math.max(0, Math.min(scene.duration, time)));
                for (const key of ['x', 'y', 'scale', 'rotation']) context.camera[key] = camera[key];
            },
            reset() {
                if (disposed) return;
                timelineMotion.reset();
                    },
            dispose() {
                if(disposed)return;
                disposed=true;
                timelineMotion.dispose();
                for (const g of mounted.slice().reverse()) g.remove();
                for (const ns of namespaces) ns.release();
            }
        };
    } catch (error) {
        if(timelineMotion)timelineMotion.dispose();
        for(const g of mounted.slice().reverse())g.remove();
        for(const ns of namespaces)ns.release();
        throw error;
    }
}
return {createEpisodeScene};
})();

export function createScene(context) {
    return createEpisodeScene(context, 'scene-004');
}
